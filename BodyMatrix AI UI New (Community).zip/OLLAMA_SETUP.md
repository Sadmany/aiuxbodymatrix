# Ollama AI Integration Setup Guide

This application is ready for Ollama integration! Follow these steps to connect your AI chat app to a local AI model.

## Quick Start

### 1. Install Ollama

Download and install Ollama from the official website:
- **Website**: https://ollama.ai/download
- **macOS/Linux**: `curl -fsSL https://ollama.ai/install.sh | sh`
- **Windows**: Download the installer from the website

### 2. Pull an AI Model

Choose and download a model (we recommend starting with `llama2`):

```bash
# Popular models:
ollama pull llama2          # Good balance of speed and quality
ollama pull mistral         # Faster, good for quick responses
ollama pull codellama       # Optimized for code-related tasks
ollama pull llama2:13b      # More powerful but slower
```

### 3. Start Ollama Server

```bash
ollama serve
```

The server will start on `http://localhost:11434` by default.

### 4. Configure Your Application

Open `src/app/services/ollamaService.ts` and adjust these settings if needed:

```typescript
const OLLAMA_BASE_URL = 'http://localhost:11434'; // Change if using different host/port
const DEFAULT_MODEL = 'llama2'; // Change to your preferred model
```

### 5. Test the Connection

The app will automatically connect to Ollama when you send a message. If there's a connection issue, you'll see an error message with troubleshooting steps.

## Features

### ✅ Response Styles
- **Fast**: Quick responses with balanced creativity (temperature: 0.7)
- **Thinking**: More thoughtful responses with detailed reasoning (temperature: 0.5)
- **Pro**: Precise, accurate responses for professional use (temperature: 0.3)

### ✅ Slash Commands
- `/think` - Deep thinking and analysis mode
- `/step` - Step-by-step breakdown of complex topics
- `/review` - Detailed review and analysis of attached documents
- `/refine` - Polished, error-free responses

### ✅ Chat History Management
- Auto-generated chat titles using AI
- Persistent chat history with timestamps
- Pin important conversations
- Search through chat history

### ✅ File Attachments
- Attach up to 5 files per message
- Support for images and documents
- AI context awareness of attached files

### ✅ Message Editing & Regeneration
- Edit previous messages to refine your prompts
- Regenerate AI responses with different parameters
- Maintain full conversation context

## Architecture

### Service Layer (`src/app/services/ollamaService.ts`)

The `ollamaService` handles all communication with Ollama:

```typescript
// Send a chat message
const response = await sendChatMessage(
  conversationHistory,
  responseStyle,
  command,
  attachments
);

// Generate a chat title
const title = await generateChatTitle(firstMessage);

// Check connection
const isConnected = await checkOllamaConnection();

// Get available models
const models = await getAvailableModels();
```

### Key Integration Points

1. **App.tsx** - Main application logic
   - `handleSend()` - Sends messages to Ollama and manages chat history
   - `handleRegenerate()` - Regenerates AI responses
   - `handleEditMessage()` - Handles message editing and re-generation

2. **ollamaService.ts** - AI backend service
   - `sendChatMessage()` - Core AI communication function
   - `generateChatTitle()` - Auto-generates descriptive chat titles
   - `getCommandSystemPrompt()` - Configures AI behavior based on commands

## Troubleshooting

### "Connection Error" Message

**Problem**: Can't connect to Ollama server

**Solutions**:
1. Check if Ollama is running: `ollama list`
2. Start the server: `ollama serve`
3. Verify the URL in `ollamaService.ts` matches your Ollama server

### "Model Not Found" Error

**Problem**: The specified model isn't installed

**Solutions**:
1. Check installed models: `ollama list`
2. Pull the model: `ollama pull llama2`
3. Update `DEFAULT_MODEL` in `ollamaService.ts`

### Slow Responses

**Problem**: AI takes too long to respond

**Solutions**:
1. Use a smaller model (e.g., `mistral` instead of `llama2:13b`)
2. Switch to "Fast" response style
3. Ensure sufficient system resources (RAM, CPU)

### Poor Quality Responses

**Problem**: AI responses aren't good enough

**Solutions**:
1. Use a larger model (e.g., `llama2:13b` or `llama2:70b`)
2. Switch to "Pro" or "Thinking" response style
3. Use slash commands to guide the AI (`/think`, `/refine`)
4. Provide more context in your prompts

## Advanced Configuration

### Custom System Prompts

Edit `getCommandSystemPrompt()` in `ollamaService.ts` to customize AI behavior:

```typescript
function getCommandSystemPrompt(command: string): string {
  switch (command) {
    case '/think':
      return 'Your custom prompt for thinking mode...';
    // Add your own commands here
  }
}
```

### Response Parameters

Adjust temperature, top_p, and top_k in `getModelOptions()`:

```typescript
const getModelOptions = (style: 'fast' | 'thinking' | 'pro') => {
  switch (style) {
    case 'fast':
      return {
        temperature: 0.7,  // Higher = more creative
        top_p: 0.9,        // Nucleus sampling
        top_k: 40          // Top-k sampling
      };
  }
};
```

### Using Different Models

Change the model per request by modifying the `sendChatMessage` function:

```typescript
const requestPayload: OllamaRequest = {
  model: 'codellama', // Change this
  messages: [...systemMessages, ...messages],
  // ...
};
```

## Performance Tips

1. **Use smaller models for faster responses**:
   - `mistral` (7B parameters) - Fast, good quality
   - `llama2` (7B parameters) - Balanced
   - `llama2:13b` (13B parameters) - Better quality, slower

2. **Optimize system resources**:
   - Close unnecessary applications
   - Ensure sufficient RAM (8GB minimum, 16GB+ recommended)
   - Use SSD storage for faster model loading

3. **Adjust response styles**:
   - Use "Fast" for quick questions
   - Use "Thinking" for complex analysis
   - Use "Pro" for accuracy-critical tasks

## Security Notes

- Ollama runs locally on your machine - no data is sent to external servers
- All conversations stay on your device
- Private mode ensures chat history isn't saved (when implemented)

## Next Steps

### Enhancements You Can Add

1. **Streaming Responses**: Show AI responses as they're generated
2. **Multi-Model Support**: Switch between different models in the UI
3. **RAG (Retrieval-Augmented Generation)**: Connect to a vector database
4. **Export Chats**: Save conversations as PDF or Markdown
5. **Voice Input**: Add speech-to-text for voice messages

### Code Examples

#### Streaming Responses

```typescript
// In ollamaService.ts
export async function sendChatMessageStream(
  messages: ChatMessage[],
  onChunk: (chunk: string) => void
) {
  const response = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: DEFAULT_MODEL,
      messages,
      stream: true  // Enable streaming
    }),
  });

  const reader = response.body?.getReader();
  const decoder = new TextDecoder();

  while (true) {
    const { done, value } = await reader!.read();
    if (done) break;

    const chunk = decoder.decode(value);
    const lines = chunk.split('\n').filter(line => line.trim());

    for (const line of lines) {
      try {
        const data = JSON.parse(line);
        if (data.message?.content) {
          onChunk(data.message.content);
        }
      } catch (e) {
        // Ignore parse errors
      }
    }
  }
}
```

## Resources

- **Ollama Documentation**: https://github.com/ollama/ollama
- **Model Library**: https://ollama.ai/library
- **API Reference**: https://github.com/ollama/ollama/blob/main/docs/api.md
- **Community**: https://discord.gg/ollama

## Support

If you encounter issues:
1. Check the browser console for error messages
2. Verify Ollama is running: `curl http://localhost:11434/api/tags`
3. Check Ollama logs for errors
4. Consult the Ollama documentation

---

**Happy coding! 🚀**
