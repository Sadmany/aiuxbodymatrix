/**
 * Ollama AI Integration Service
 *
 * This service handles all communication with the Ollama API for AI chat functionality.
 * Ollama is a local AI model server that runs models like Llama 2, Mistral, etc.
 *
 * Setup Instructions:
 * 1. Install Ollama: https://ollama.ai/download
 * 2. Pull a model: `ollama pull llama2` (or mistral, codellama, etc.)
 * 3. Start Ollama server: `ollama serve`
 * 4. Update OLLAMA_BASE_URL if running on different host/port
 */

// Configuration
const OLLAMA_BASE_URL = 'http://localhost:11434'; // Default Ollama server URL
const DEFAULT_MODEL = 'llama2'; // Change to your preferred model (llama2, mistral, codellama, etc.)

/**
 * Message structure for chat history
 */
export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

/**
 * Ollama API request payload
 */
interface OllamaRequest {
  model: string;
  messages: ChatMessage[];
  stream?: boolean;
  options?: {
    temperature?: number;
    top_p?: number;
    top_k?: number;
  };
}

/**
 * Ollama API response structure
 */
interface OllamaResponse {
  model: string;
  created_at: string;
  message: {
    role: string;
    content: string;
  };
  done: boolean;
  total_duration?: number;
  load_duration?: number;
  prompt_eval_duration?: number;
  eval_duration?: number;
  eval_count?: number;
}

/**
 * Response configuration based on response style
 */
const getModelOptions = (style: 'fast' | 'thinking' | 'pro') => {
  switch (style) {
    case 'fast':
      return {
        temperature: 0.7,
        top_p: 0.9,
        top_k: 40
      };
    case 'thinking':
      return {
        temperature: 0.5,
        top_p: 0.95,
        top_k: 50
      };
    case 'pro':
      return {
        temperature: 0.3,
        top_p: 0.98,
        top_k: 60
      };
    default:
      return {
        temperature: 0.7,
        top_p: 0.9,
        top_k: 40
      };
  }
};

/**
 * Main function to send a chat message to Ollama and get a response
 *
 * @param messages - Array of chat messages (conversation history)
 * @param responseStyle - Response style: 'fast', 'thinking', or 'pro'
 * @param command - Optional command modifier (e.g., '/think', '/step')
 * @param attachments - Optional file attachments (not yet fully supported by Ollama)
 * @returns Promise with AI response and metadata
 */
export async function sendChatMessage(
  messages: ChatMessage[],
  responseStyle: 'fast' | 'thinking' | 'pro' = 'fast',
  command?: string | null,
  attachments?: any[]
): Promise<{
  content: string;
  thinkingTime?: number;
  responseTime: number;
  suggestions: string[];
}> {
  try {
    const startTime = Date.now();

    // Add system message for commands
    const systemMessages: ChatMessage[] = [];

    if (command) {
      systemMessages.push({
        role: 'system',
        content: getCommandSystemPrompt(command)
      });
    }

    // Add attachment context if files are attached
    if (attachments && attachments.length > 0) {
      systemMessages.push({
        role: 'system',
        content: `The user has attached ${attachments.length} file(s): ${attachments.map(a => a.name).join(', ')}. Please acknowledge these files in your response.`
      });
    }

    // Prepare the request payload
    const requestPayload: OllamaRequest = {
      model: DEFAULT_MODEL,
      messages: [...systemMessages, ...messages],
      stream: false,
      options: getModelOptions(responseStyle)
    };

    // Make the API call to Ollama
    const response = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestPayload),
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.status} ${response.statusText}`);
    }

    const data: OllamaResponse = await response.json();
    const endTime = Date.now();

    // Calculate response time
    const responseTime = (endTime - startTime) / 1000;

    // Calculate thinking time if using 'thinking' mode
    const thinkingTime = responseStyle === 'thinking'
      ? (data.prompt_eval_duration ? data.prompt_eval_duration / 1_000_000_000 : undefined)
      : undefined;

    // Generate suggested follow-up questions
    const suggestions = generateSuggestions(data.message.content, command);

    return {
      content: data.message.content,
      thinkingTime,
      responseTime,
      suggestions
    };

  } catch (error) {
    console.error('Error communicating with Ollama:', error);

    // Return a helpful error message
    return {
      content: getFallbackErrorMessage(error),
      responseTime: 0,
      suggestions: [
        'Is Ollama running?',
        'Check connection settings',
        'Try a different model'
      ]
    };
  }
}

/**
 * Generate a chat title based on the first user message
 * Uses Ollama to create a concise, descriptive title
 *
 * @param firstMessage - The first user message in the conversation
 * @returns Promise with generated title
 */
export async function generateChatTitle(firstMessage: string): Promise<string> {
  try {
    const requestPayload: OllamaRequest = {
      model: DEFAULT_MODEL,
      messages: [
        {
          role: 'system',
          content: 'Generate a short, concise title (max 6 words) for a chat conversation based on the user\'s first message. Reply with ONLY the title, nothing else.'
        },
        {
          role: 'user',
          content: firstMessage
        }
      ],
      stream: false,
      options: {
        temperature: 0.3,
        top_p: 0.9
      }
    };

    const response = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestPayload),
    });

    if (!response.ok) {
      throw new Error('Failed to generate title');
    }

    const data: OllamaResponse = await response.json();

    // Clean up the title (remove quotes, trim, limit length)
    let title = data.message.content.trim().replace(/^["']|["']$/g, '');

    // Truncate if too long
    if (title.length > 50) {
      title = title.substring(0, 47) + '...';
    }

    return title;

  } catch (error) {
    console.error('Error generating chat title:', error);
    // Fallback: Use first few words of the message
    const words = firstMessage.split(' ').slice(0, 6).join(' ');
    return words.length > 50 ? words.substring(0, 47) + '...' : words;
  }
}

/**
 * Get system prompt based on command
 */
function getCommandSystemPrompt(command: string): string {
  switch (command) {
    case '/think':
      return 'You are in deep thinking mode. Provide thorough, analytical responses with detailed reasoning. Break down complex topics and explain your thought process.';

    case '/step':
      return 'Break down your response into clear, numbered steps. Provide a structured, step-by-step approach to solving the problem or answering the question.';

    case '/review':
      return 'You are in review mode. Carefully analyze and review the attached documents or information. Provide constructive feedback, identify key points, and summarize important details.';

    case '/refine':
      return 'You are in refinement mode. Focus on providing the best possible, error-free version of your response. Double-check facts, improve clarity, and ensure accuracy.';

    default:
      return 'You are a helpful AI assistant. Provide clear, accurate, and helpful responses.';
  }
}

/**
 * Generate relevant follow-up suggestions based on response
 */
function generateSuggestions(content: string, command?: string | null): string[] {
  // Base suggestions
  const baseSuggestions = [
    'Can you elaborate on that?',
    'What are the alternatives?',
    'How does this work in practice?'
  ];

  // Command-specific suggestions
  if (command === '/think') {
    return [
      'Can you explain the reasoning behind this?',
      'What are potential counterarguments?',
      'What assumptions are we making?'
    ];
  } else if (command === '/step') {
    return [
      'Can you add more detail to step 3?',
      'What if I skip a step?',
      'Are there any prerequisites?'
    ];
  } else if (command === '/review') {
    return [
      'What are the main strengths?',
      'What could be improved?',
      'Are there any concerns?'
    ];
  } else if (command === '/refine') {
    return [
      'Is this the optimal approach?',
      'Can this be simplified further?',
      'What edge cases should I consider?'
    ];
  }

  return baseSuggestions;
}

/**
 * Get user-friendly error message
 */
function getFallbackErrorMessage(error: any): string {
  const errorMessage = error?.message || 'Unknown error';

  if (errorMessage.includes('fetch')) {
    return `⚠️ **Connection Error**\n\nCouldn't connect to Ollama server. Please ensure:\n\n1. Ollama is installed (https://ollama.ai/download)\n2. Ollama server is running (\`ollama serve\`)\n3. Server is accessible at ${OLLAMA_BASE_URL}\n\nFor troubleshooting, check the developer console for more details.`;
  }

  if (errorMessage.includes('404')) {
    return `⚠️ **Model Not Found**\n\nThe model "${DEFAULT_MODEL}" is not available. Please:\n\n1. Pull the model: \`ollama pull ${DEFAULT_MODEL}\`\n2. Or update DEFAULT_MODEL in ollamaService.ts to a model you have installed\n\nList installed models: \`ollama list\``;
  }

  return `⚠️ **Error**\n\nAn error occurred while communicating with the AI:\n\n${errorMessage}\n\nPlease check your Ollama setup and try again.`;
}

/**
 * Check if Ollama server is available
 * Useful for health checks and connection validation
 */
export async function checkOllamaConnection(): Promise<boolean> {
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/tags`, {
      method: 'GET',
    });
    return response.ok;
  } catch (error) {
    console.error('Ollama connection check failed:', error);
    return false;
  }
}

/**
 * Get list of available models from Ollama
 */
export async function getAvailableModels(): Promise<string[]> {
  try {
    const response = await fetch(`${OLLAMA_BASE_URL}/api/tags`, {
      method: 'GET',
    });

    if (!response.ok) {
      throw new Error('Failed to fetch models');
    }

    const data = await response.json();
    return data.models?.map((m: any) => m.name) || [];
  } catch (error) {
    console.error('Error fetching available models:', error);
    return [];
  }
}
