import { useState, useEffect } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';

interface RenameDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (newTitle: string) => void;
  currentTitle: string;
}

export function RenameDialog({
  open,
  onOpenChange,
  onConfirm,
  currentTitle,
}: RenameDialogProps) {
  const [title, setTitle] = useState(currentTitle);

  useEffect(() => {
    setTitle(currentTitle);
  }, [currentTitle, open]);

  const handleConfirm = () => {
    if (title.trim()) {
      onConfirm(title);
      onOpenChange(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleConfirm();
    }
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-white border border-black/[0.06] rounded-2xl shadow-xl w-[90vw] sm:w-full sm:max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-[16px] sm:text-[18px] font-medium text-[#171717]">
            Rename Chat
          </AlertDialogTitle>
          <AlertDialogDescription className="text-[13px] sm:text-[14px] text-[#737373] mt-2">
            Enter a new name for this chat.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="my-4">
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={handleKeyDown}
            className="w-full px-4 py-2.5 bg-white border border-black/[0.06] rounded-xl text-[14px] text-[#171717] placeholder:text-[#a3a3a3] outline-none focus:border-black/[0.1] transition-all duration-200"
            placeholder="Chat title"
            autoFocus
          />
        </div>
        <AlertDialogFooter className="flex gap-2 sm:gap-3">
          <AlertDialogCancel className="px-4 sm:px-5 py-2.5 text-[13px] sm:text-[14px] font-normal text-[#737373] bg-[#f5f5f4] hover:bg-[#e5e5e5] rounded-xl transition-all duration-200">
            Cancel
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirm}
            className="px-4 sm:px-5 py-2.5 text-[13px] sm:text-[14px] font-normal text-white bg-[#171717] hover:bg-[#0a0a0a] rounded-xl transition-all duration-200"
          >
            Rename
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
