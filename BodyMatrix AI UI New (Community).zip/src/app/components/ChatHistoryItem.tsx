import { useState, useEffect, useRef } from 'react';
import { MessageSquare, MoreVertical, Trash2, Edit, Pin, Check, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ChatHistoryItemProps {
  title: string;
  active: boolean;
  isPinned?: boolean;
  onClick: () => void;
  onDelete: () => void;
  onRename: () => void;
  onPin: () => void;
}

export function ChatHistoryItem({ title, active, isPinned = false, onClick, onDelete, onRename, onPin }: ChatHistoryItemProps) {
  const [showMenu, setShowMenu] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowDeleteConfirm(true);
    setShowMenu(false);
  };

  const handleConfirmDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete();
  };

  const handleCancelDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowDeleteConfirm(false);
  };

  const handleRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    onRename();
    setShowMenu(false);
  };

  const handlePin = (e: React.MouseEvent) => {
    e.stopPropagation();
    onPin();
    setShowMenu(false);
  };

  const handleMenuClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowMenu(!showMenu);
  };

  const handleItemClick = (e: React.MouseEvent) => {
    // Don't trigger if clicking the menu button or menu itself
    const target = e.target as HTMLElement;
    if (target.closest('button')) {
      return;
    }
    onClick();
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    };

    if (showMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showMenu]);

  return (
    <div
      ref={menuRef}
      className="relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <motion.div
        whileTap={{ scale: 0.98 }}
        onClick={handleItemClick}
        className={`
          w-full text-left px-3 py-2.5 rounded-xl transition-all duration-200
          flex items-center gap-2.5 group cursor-pointer relative
          ${active
            ? 'bg-[#f5f5f4] text-[#171717]'
            : 'text-[#737373] hover:bg-[#f5f5f4] hover:text-[#171717]'
          }
        `}
      >
        <MessageSquare className={`w-3.5 h-3.5 flex-shrink-0 ${active ? 'text-[#171717]' : 'text-[#646464] group-hover:text-[#737373]'}`} strokeWidth={1.5} />
        <span className="text-[13px] truncate leading-tight flex-1 min-w-0">
          {title}
        </span>
        {isPinned && (
          <Pin className="w-3 h-3 flex-shrink-0 text-[#737373]" strokeWidth={1.5} fill="currentColor" />
        )}

        {/* Show delete confirm or menu button */}
        <div className="flex-shrink-0 flex items-center gap-1">
          {showDeleteConfirm ? (
            <>
              <motion.button
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleConfirmDelete}
                className="w-6 h-6 flex items-center justify-center hover:bg-[#f5f5f4] rounded-lg transition-all duration-200"
                title="Confirm delete"
              >
                <Check className="w-3.5 h-3.5 text-[#646464]" strokeWidth={2.5} />
              </motion.button>
              <motion.button
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleCancelDelete}
                className="w-6 h-6 flex items-center justify-center hover:bg-[#f5f5f4] rounded-lg transition-all duration-200"
                title="Cancel delete"
              >
                <X className="w-3.5 h-3.5 text-[#646464]" strokeWidth={2.5} />
              </motion.button>
            </>
          ) : (
            <div className="w-6 h-6">
              {isHovered && (
                <motion.button
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={handleMenuClick}
                  className="w-full h-full flex items-center justify-center hover:bg-[#e5e5e5] rounded-lg transition-all duration-200"
                >
                  <MoreVertical className="w-3.5 h-3.5 text-[#737373]" strokeWidth={1.5} />
                </motion.button>
              )}
            </div>
          )}
        </div>
      </motion.div>

      {/* Context Menu */}
      <AnimatePresence>
        {showMenu && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute right-2 top-full mt-1 bg-white border border-black/[0.06] rounded-xl shadow-lg py-1.5 z-10 min-w-[140px]"
          >
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={handleRename}
              className="w-full px-3 py-2 text-left text-[13px] text-[#171717] hover:bg-[#f5f5f4] transition-all duration-200 flex items-center gap-2.5"
            >
              <Edit className="w-3.5 h-3.5" strokeWidth={1.5} />
              Rename
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={handlePin}
              className="w-full px-3 py-2 text-left text-[13px] text-[#171717] hover:bg-[#f5f5f4] transition-all duration-200 flex items-center gap-2.5"
            >
              <Pin className="w-3.5 h-3.5" strokeWidth={1.5} />
              {isPinned ? 'Unpin' : 'Pin'}
            </motion.button>
            <div className="h-px bg-black/[0.06] my-1.5" />
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={handleDeleteClick}
              className="w-full px-3 py-2 text-left text-[13px] text-[#dc2626] hover:bg-[#fef2f2] transition-all duration-200 flex items-center gap-2.5"
            >
              <Trash2 className="w-3.5 h-3.5" strokeWidth={1.5} />
              Delete
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
