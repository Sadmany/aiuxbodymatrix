import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';

interface ResponseStyleSelectorProps {
  selectedStyle: 'fast' | 'thinking' | 'pro';
  onStyleChange: (style: 'fast' | 'thinking' | 'pro') => void;
}

export function ResponseStyleSelector({ selectedStyle, onStyleChange }: ResponseStyleSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);

  const styles = [
    { id: 'fast' as const, name: 'Fast', subtext: 'quick respond' },
    { id: 'thinking' as const, name: 'Thinking', subtext: 'deep reasoning' },
    { id: 'pro' as const, name: 'Pro', subtext: 'advanced analytics', disabled: true },
  ];

  const currentStyle = styles.find(s => s.id === selectedStyle);

  return (
    <div className="relative">
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 bg-[#f5f5f4] hover:bg-[#ebebeb] rounded-xl transition-all duration-200 text-[12px] text-[#171717]"
      >
        <span className="font-medium">{currentStyle?.name}</span>
        <ChevronDown className="w-3 h-3" strokeWidth={2.5} />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <div
              className="fixed inset-0 z-40"
              onClick={() => setIsOpen(false)}
            />

            {/* Pop-up */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: -10 }}
              transition={{ duration: 0.15 }}
              className="absolute bottom-full right-0 mb-2 bg-white border border-black/[0.06] rounded-2xl shadow-lg p-2 min-w-[200px] z-50"
            >
              {styles.map((style) => (
                <button
                  key={style.id}
                  onClick={() => {
                    if (!style.disabled) {
                      onStyleChange(style.id);
                      setIsOpen(false);
                    }
                  }}
                  disabled={style.disabled}
                  className={`w-full text-left px-3 py-2.5 rounded-xl transition-all duration-200 ${
                    style.disabled
                      ? 'opacity-50 cursor-not-allowed'
                      : 'hover:bg-[#f5f5f4]'
                  } ${
                    selectedStyle === style.id ? 'bg-[#f5f5f4]' : ''
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-[13px] font-medium text-[#171717]">
                        {style.name}
                      </div>
                      <div className="text-[11px] text-[#646464]">
                        {style.subtext}
                      </div>
                    </div>
                    {style.disabled && (
                      <span className="text-[10px] text-[#646464] italic">
                        Coming soon
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
