import { motion, AnimatePresence } from 'motion/react';
import { FileUp, Image as ImageIcon } from 'lucide-react';

interface AttachmentBarProps {
  isOpen: boolean;
  onAttachFile: () => void;
  onAttachImage: () => void;
}

export function AttachmentBar({ isOpen, onAttachFile, onAttachImage }: AttachmentBarProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 10, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 10, scale: 0.95 }}
          transition={{ duration: 0.2, ease: [0.4, 0, 0.2, 1] }}
          className="absolute bottom-full left-0 mb-3 bg-white rounded-2xl border border-black/[0.06] shadow-lg p-2 flex flex-col gap-1 z-10"
        >
          {/* Choose Image */}
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onAttachImage}
            className="flex items-center gap-2 px-4 py-2.5 hover:bg-[#f5f5f4] rounded-xl transition-all duration-200 whitespace-nowrap"
          >
            <ImageIcon className="w-4 h-4 text-[#171717]" strokeWidth={2.5} />
            <span className="text-[13px] font-medium text-[#171717]">Choose Image</span>
          </motion.button>

          {/* Choose File */}
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onAttachFile}
            className="flex items-center gap-2 px-4 py-2.5 hover:bg-[#f5f5f4] rounded-xl transition-all duration-200 whitespace-nowrap"
          >
            <FileUp className="w-4 h-4 text-[#171717]" strokeWidth={2.5} />
            <span className="text-[13px] font-medium text-[#171717]">Choose File</span>
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
