import { useState, useRef, useImperativeHandle, forwardRef, useEffect } from 'react';
import { Paperclip, ArrowUp, Mic, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AttachmentBar } from './AttachmentBar';
import { AttachmentPreview, AttachedFile } from './AttachmentPreview';
import { CommandSelector, Command } from './CommandSelector';
import { ResponseStyleSelector } from './ResponseStyleSelector';

interface InputAreaProps {
  value: string;
  onChange: (value: string) => void;
  onSend: (command?: string | null) => void;
  selectedCommand?: string | null;
  onCommandRemove?: () => void;
  responseStyle: 'fast' | 'thinking' | 'pro';
  onResponseStyleChange: (style: 'fast' | 'thinking' | 'pro') => void;
  attachedFiles?: AttachedFile[];
  onAttachedFilesChange?: (files: AttachedFile[]) => void;
}

export interface InputAreaRef {
  focus: () => void;
  getCommand: () => string | null;
}

export const InputArea = forwardRef<InputAreaRef, InputAreaProps>(({
  value,
  onChange,
  onSend,
  selectedCommand,
  onCommandRemove,
  responseStyle,
  onResponseStyleChange,
  attachedFiles: externalAttachedFiles,
  onAttachedFilesChange
}, ref) => {
  const [isFocused, setIsFocused] = useState(false);
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [placeholderFade, setPlaceholderFade] = useState(true);
  const [attachmentBarOpen, setAttachmentBarOpen] = useState(false);
  const [internalAttachedFiles, setInternalAttachedFiles] = useState<AttachedFile[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [commandSelectorOpen, setCommandSelectorOpen] = useState(false);
  const [commandSearch, setCommandSearch] = useState('');
  const [internalCommand, setInternalCommand] = useState<string | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const attachedFiles = externalAttachedFiles ?? internalAttachedFiles;
  const setAttachedFiles = onAttachedFilesChange ?? setInternalAttachedFiles;

  const placeholders = ['Ask anything...', 'Type / for commands'];

  const activeCommand = selectedCommand || internalCommand;

  useImperativeHandle(ref, () => ({
    focus: () => {
      const textarea = textareaRef.current;
      if (textarea) {
        // Force focus with multiple attempts for reliability
        textarea.focus();

        // Ensure textarea is visible and enabled
        textarea.disabled = false;
        textarea.style.opacity = '1';
        textarea.style.pointerEvents = 'auto';

        // Move cursor to end of text
        const length = textarea.value.length;
        textarea.setSelectionRange(length, length);

        // Double-check focus after a brief delay
        setTimeout(() => {
          if (document.activeElement !== textarea) {
            textarea.focus();
            textarea.setSelectionRange(length, length);
          }
        }, 50);
      }
    },
    getCommand: () => activeCommand
  }));

  // Auto-resize textarea based on content - optimized
  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    // Use requestAnimationFrame for smooth updates
    requestAnimationFrame(() => {
      // Reset height to auto to get the correct scrollHeight
      textarea.style.height = 'auto';

      // Calculate new height based on content
      const newHeight = Math.min(textarea.scrollHeight, 180); // Max height: 180px (high-medium)
      textarea.style.height = `${newHeight}px`;

      // Enable/disable scrolling based on whether we've hit max height
      textarea.style.overflowY = textarea.scrollHeight > 180 ? 'auto' : 'hidden';
    });
  }, [value]);

  // Cycling placeholder animation - every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setPlaceholderFade(false);
      setTimeout(() => {
        setPlaceholderIndex((prev) => (prev + 1) % placeholders.length);
        setPlaceholderFade(true);
      }, 300);
    }, 5000);

    return () => clearInterval(interval);
  }, [placeholders.length]);

  const handleInputChange = (newValue: string) => {
    // Check if "/" is typed at the beginning
    if (newValue.startsWith('/') && !activeCommand) {
      setCommandSelectorOpen(true);
      setCommandSearch(newValue);
    } else if (commandSelectorOpen && !newValue.startsWith('/')) {
      setCommandSelectorOpen(false);
      setCommandSearch('');
    }

    onChange(newValue);
  };

  const handleCommandSelect = (command: Command) => {
    if (selectedCommand !== undefined) {
      // External command control - notify parent
      // Parent should handle this via onCommandSelect if provided
      setInternalCommand(command.name);
    } else {
      // Internal command control
      setInternalCommand(command.name);
    }
    setCommandSelectorOpen(false);
    onChange(''); // Clear the "/" text
  };

  const handleCommandRemoveInternal = () => {
    setInternalCommand(null);
    if (onCommandRemove) {
      onCommandRemove();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Prevent Alt-key shortcuts from interfering with Enter
    if (e.key === 'Enter' && e.altKey) {
      e.preventDefault();
      return;
    }

    // Escape closes command selector
    if (e.key === 'Escape' && commandSelectorOpen) {
      e.preventDefault();
      setCommandSelectorOpen(false);
      setCommandSearch('');
      return;
    }

    if (e.key === 'Enter' && !e.shiftKey && !e.altKey) {
      e.preventDefault();

      const trimmedValue = value.trim();

      // Don't send if only command is selected without text
      if (!trimmedValue && activeCommand) {
        return;
      }

      if (trimmedValue) {
        onSend(activeCommand);
        setAttachedFiles([]);
        setInternalCommand(null);
      }
    }
  };

  const handleAttachFile = () => {
    if (attachedFiles.length >= 5) {
      alert('Maximum 5 attachments allowed');
      return;
    }
    fileInputRef.current?.click();
    setAttachmentBarOpen(false);
  };

  const handleAttachImage = () => {
    if (attachedFiles.length >= 5) {
      alert('Maximum 5 attachments allowed');
      return;
    }
    imageInputRef.current?.click();
    setAttachmentBarOpen(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);

    // Calculate how many files we can still add (max 5 total)
    const remainingSlots = 5 - attachedFiles.length;
    const filesToAdd = files.slice(0, remainingSlots); // Only take first N files that fit

    if (files.length > remainingSlots) {
      alert(`Maximum 5 attachments allowed. Only adding first ${remainingSlots} file(s).`);
    }

    filesToAdd.forEach(file => {
      const newFile: AttachedFile = {
        id: Math.random().toString(36).substr(2, 9),
        name: file.name,
        type: file.type.startsWith('image/') ? 'image' : 'file',
        size: file.size,
      };

      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          newFile.preview = e.target?.result as string;
          setAttachedFiles(prev => {
            if (prev.length >= 5) return prev;
            return [...prev, newFile];
          });
        };
        reader.readAsDataURL(file);
      } else {
        setAttachedFiles(prev => {
          if (prev.length >= 5) return prev;
          return [...prev, newFile];
        });
      }
    });

    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
    if (imageInputRef.current) {
      imageInputRef.current.value = '';
    }
  };

  const handleRemoveFile = (id: string) => {
    setAttachedFiles(prev => prev.filter(f => f.id !== id));
  };

  const handleVoiceToggle = () => {
    setIsRecording(!isRecording);
    // In a real implementation, this would start/stop voice recognition
  };

  return (
    <div className="relative">
      {/* Hidden file inputs */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="*/*"
        onChange={handleFileChange}
        className="hidden"
      />
      <input
        ref={imageInputRef}
        type="file"
        multiple
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Attachment Preview */}
      <AttachmentPreview files={attachedFiles} onRemove={handleRemoveFile} />

      <div
        className={`
          bg-white border transition-all duration-300 shadow-sm
          ${attachedFiles.length > 0 ? 'rounded-b-[28px] border-t-0' : 'rounded-[28px]'}
          ${isFocused ? 'border-black/[0.1] shadow-md' : 'border-black/[0.06]'}
        `}
      >
        {/* Input Field */}
        <div className="px-5 pt-4 pb-2 relative">
          {/* Command Pill */}
          <AnimatePresence>
            {activeCommand && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="inline-flex items-center gap-1.5 bg-[#f5f5f4] border border-black/[0.06] rounded-full px-3 py-1 mb-2 text-[12px] text-[#171717] font-medium"
              >
                <span>{activeCommand}</span>
                <button
                  onClick={handleCommandRemoveInternal}
                  className="hover:bg-black/[0.06] rounded-full p-0.5 transition-colors"
                >
                  <X className="w-3 h-3" strokeWidth={2.5} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Command Selector */}
          <CommandSelector
            isOpen={commandSelectorOpen}
            searchTerm={commandSearch}
            onSelect={handleCommandSelect}
            onClose={() => {
              setCommandSelectorOpen(false);
              setCommandSearch('');
            }}
          />

          <textarea
            ref={textareaRef}
            value={value}
            onChange={(e) => {
              // Enforce 1000 character limit
              if (e.target.value.length <= 1000) {
                handleInputChange(e.target.value);
              }
            }}
            onKeyDown={handleKeyDown}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            placeholder={placeholders[placeholderIndex]}
            rows={1}
            autoFocus={false}
            disabled={false}
            className={`w-full resize-none bg-transparent border-none outline-none text-[13px] md:text-[14px] leading-relaxed text-[#171717] placeholder:text-[#646464] opacity-100 ${
              placeholderFade ? 'placeholder-fade-in' : 'placeholder-fade-out'
            }`}
            style={{
              minHeight: '24px',
              height: '24px', // Start with single line height
              maxHeight: '180px' // High-medium height limit
            }}
          />
        </div>

        {/* Bottom Row */}
        <div className="flex items-center justify-between px-4 pb-3">
          <div className="flex items-center gap-2 sm:gap-3 relative">
            {/* Paperclip Icon */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setAttachmentBarOpen(!attachmentBarOpen)}
              className={`p-2 transition-colors rounded-lg ${
                attachmentBarOpen ? 'text-[#171717] bg-[#f5f5f4]' : 'text-[#737373] hover:bg-[#f5f5f4]'
              }`}
              disabled={attachedFiles.length >= 5}
            >
              <Paperclip className="w-4 h-4" strokeWidth={2.5} />
            </motion.button>

            {/* Attachment Bar */}
            <AttachmentBar
              isOpen={attachmentBarOpen}
              onAttachFile={handleAttachFile}
              onAttachImage={handleAttachImage}
            />

            {/* Voice/Mic Icon */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={handleVoiceToggle}
              className={`p-2 transition-colors rounded-lg ${
                isRecording ? 'text-red-500 bg-red-50' : 'text-[#737373] hover:bg-[#f5f5f4]'
              }`}
            >
              <Mic className="w-4 h-4" strokeWidth={2.5} />
            </motion.button>

            {/* Character Counter */}
            {value.length > 0 && (
              <span
                className={`text-[11px] transition-colors ${
                  value.length > 900 ? 'text-[#dc2626]' : 'text-[#646464]'
                }`}
              >
                {value.length}/1000
              </span>
            )}
          </div>

          {/* Response Style Selector & Send Button */}
          <div className="flex items-center gap-2">
            {value.trim() && (
              <div className="flex items-center gap-2">
                <ResponseStyleSelector
                  selectedStyle={responseStyle}
                  onStyleChange={onResponseStyleChange}
                />
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    onSend(activeCommand);
                    setAttachedFiles([]);
                    setInternalCommand(null);
                  }}
                  className="rounded-xl w-9 h-9 bg-[#171717] hover:bg-[#0a0a0a] text-white shadow-sm transition-all duration-300 flex items-center justify-center"
                >
                  <ArrowUp className="w-5 h-5" strokeWidth={2.5} />
                </motion.button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
});

InputArea.displayName = 'InputArea';
