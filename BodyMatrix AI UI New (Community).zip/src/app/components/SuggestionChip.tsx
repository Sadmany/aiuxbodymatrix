import { motion } from 'motion/react';

interface SuggestionChipProps {
  text: string;
  onClick: (text: string) => void;
  delay?: number;
}

export function SuggestionChip({ text, onClick, delay = 0 }: SuggestionChipProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      whileTap={{ scale: 0.97 }}
      transition={{ duration: 0.3, delay }}
      onClick={() => onClick(text)}
      className="
        bg-white border border-black/[0.06] px-5 md:px-6 py-3 md:py-3.5 rounded-full
        text-[14px] md:text-[15px] text-[#404040] hover:bg-[#fafaf9] hover:border-black/[0.08]
        transition-all duration-300
        whitespace-nowrap shadow-sm hover:shadow
      "
    >
      {text}
    </motion.button>
  );
}
