import { motion, AnimatePresence } from 'motion/react';
import { X, FolderKanban, Plus } from 'lucide-react';

interface ProjectsPopupProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ProjectsPopup({ isOpen, onClose }: ProjectsPopupProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/30 z-50"
            onClick={onClose}
          />

          {/* Popup Window */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-2xl bg-[#fafafe] border border-black/[0.08] rounded-3xl shadow-2xl z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-black/[0.06]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center border border-black/[0.06]">
                  <FolderKanban className="w-5 h-5 text-[#171717]" strokeWidth={2.5} />
                </div>
                <h2 className="text-[18px] font-medium text-[#171717]">Projects</h2>
              </div>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={onClose}
                className="p-2 hover:bg-white rounded-xl transition-all duration-200"
              >
                <X className="w-5 h-5 text-[#171717]" strokeWidth={2.5} />
              </motion.button>
            </div>

            {/* Content */}
            <div className="p-6 min-h-[400px] max-h-[70vh] overflow-y-auto">
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mb-4 border border-black/[0.06]">
                  <FolderKanban className="w-8 h-8 text-[#646464]" strokeWidth={2} />
                </div>
                <h3 className="text-[16px] font-medium text-[#171717] mb-2">
                  No projects yet
                </h3>
                <p className="text-[13px] text-[#646464] mb-6 max-w-sm">
                  Create projects to organize your chats by topic or goal
                </p>
                <motion.button
                  whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-2 px-5 py-2.5 bg-[#171717] hover:bg-[#0a0a0a] text-white rounded-xl transition-all duration-200"
                >
                  <Plus className="w-4 h-4" strokeWidth={2.5} />
                  <span className="text-[14px] font-medium">Create project</span>
                </motion.button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
