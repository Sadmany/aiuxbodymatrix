import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Search, MessageSquare, Pin } from 'lucide-react';

interface ChatItem {
  id: string;
  title: string;
  lastMessageDate: Date;
  isPinned?: boolean;
}

interface SearchPopupProps {
  isOpen: boolean;
  onClose: () => void;
  chatHistory: ChatItem[];
  onSelectChat: (id: string) => void;
  activeChat: string | null;
}

export function SearchPopup({ isOpen, onClose, chatHistory, onSelectChat, activeChat }: SearchPopupProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus input when popup opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  // Filter chats based on search query
  const filteredChats = chatHistory.filter(chat =>
    chat.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group chats: Recent (last 7 days) and Earlier
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const recentChats = filteredChats.filter(chat => chat.lastMessageDate >= sevenDaysAgo);
  const earlierChats = filteredChats.filter(chat => chat.lastMessageDate < sevenDaysAgo);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/30 z-50"
            onClick={onClose}
          />

          {/* Popup Window */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[90%] max-w-2xl bg-[#fafafe] border border-black/[0.08] rounded-3xl shadow-2xl z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-black/[0.06]">
              <div className="flex items-center gap-3 flex-1">
                <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center border border-black/[0.06]">
                  <Search className="w-5 h-5 text-[#171717]" strokeWidth={2.5} />
                </div>
                <input
                  ref={inputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search all chats..."
                  className="flex-1 bg-transparent border-none outline-none text-[16px] text-[#171717] placeholder:text-[#646464]"
                />
              </div>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={onClose}
                className="p-2 hover:bg-white rounded-xl transition-all duration-200"
              >
                <X className="w-5 h-5 text-[#171717]" strokeWidth={2.5} />
              </motion.button>
            </div>

            {/* Content */}
            <div className="p-6 min-h-[400px] max-h-[70vh] overflow-y-auto" style={{ scrollbarGutter: 'stable' }}>
              {chatHistory.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center py-12">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mb-4 border border-black/[0.06]">
                    <Search className="w-8 h-8 text-[#646464]" strokeWidth={2} />
                  </div>
                  <h3 className="text-[16px] font-medium text-[#171717] mb-2">
                    No chat history
                  </h3>
                  <p className="text-[13px] text-[#646464] max-w-sm">
                    Start a new conversation to see it here
                  </p>
                </div>
              ) : filteredChats.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-[13px] text-[#646464]">
                    No results found for "{searchQuery}"
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Recent Chats */}
                  {recentChats.length > 0 && (
                    <div>
                      <div className="px-2 mb-2">
                        <span className="text-[10px] font-medium text-[#646464]">
                          Recent
                        </span>
                      </div>
                      <div className="space-y-1">
                        {recentChats.map((chat) => (
                          <motion.div
                            key={chat.id}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => {
                              onSelectChat(chat.id);
                              onClose();
                            }}
                            className={`
                              w-full text-left px-3 py-2.5 rounded-xl transition-all duration-200
                              flex items-center gap-2.5 cursor-pointer
                              ${activeChat === chat.id
                                ? 'bg-[#f5f5f4] text-[#171717]'
                                : 'text-[#737373] hover:bg-[#f5f5f4] hover:text-[#171717]'
                              }
                            `}
                          >
                            <MessageSquare className={`w-3.5 h-3.5 flex-shrink-0 ${activeChat === chat.id ? 'text-[#171717]' : 'text-[#646464]'}`} strokeWidth={1.5} />
                            <span className="text-[13px] truncate leading-tight flex-1 min-w-0">
                              {chat.title}
                            </span>
                            {chat.isPinned && (
                              <Pin className="w-3 h-3 flex-shrink-0 text-[#737373]" strokeWidth={1.5} fill="currentColor" />
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Earlier Chats */}
                  {earlierChats.length > 0 && (
                    <div>
                      <div className="px-2 mb-2">
                        <span className="text-[10px] font-medium text-[#646464]">
                          Earlier
                        </span>
                      </div>
                      <div className="space-y-1">
                        {earlierChats.map((chat) => (
                          <motion.div
                            key={chat.id}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => {
                              onSelectChat(chat.id);
                              onClose();
                            }}
                            className={`
                              w-full text-left px-3 py-2.5 rounded-xl transition-all duration-200
                              flex items-center gap-2.5 cursor-pointer
                              ${activeChat === chat.id
                                ? 'bg-[#f5f5f4] text-[#171717]'
                                : 'text-[#737373] hover:bg-[#f5f5f4] hover:text-[#171717]'
                              }
                            `}
                          >
                            <MessageSquare className={`w-3.5 h-3.5 flex-shrink-0 ${activeChat === chat.id ? 'text-[#171717]' : 'text-[#646464]'}`} strokeWidth={1.5} />
                            <span className="text-[13px] truncate leading-tight flex-1 min-w-0">
                              {chat.title}
                            </span>
                            {chat.isPinned && (
                              <Pin className="w-3 h-3 flex-shrink-0 text-[#737373]" strokeWidth={1.5} fill="currentColor" />
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
