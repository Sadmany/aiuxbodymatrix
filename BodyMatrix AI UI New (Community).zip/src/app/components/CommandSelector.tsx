import { motion, AnimatePresence } from 'motion/react';
import { Brain, List, FileSearch, Sparkles } from 'lucide-react';

export interface Command {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

interface CommandSelectorProps {
  isOpen: boolean;
  searchTerm: string;
  onSelect: (command: Command) => void;
  onClose: () => void;
}

const commands: Command[] = [
  {
    id: '/think',
    name: '/think',
    description: 'Deep thinking and analysis',
    icon: <Brain className="w-4 h-4" strokeWidth={2.5} />
  },
  {
    id: '/step',
    name: '/step',
    description: 'Breaks complex goals into a clear numbered list',
    icon: <List className="w-4 h-4" strokeWidth={2.5} />
  },
  {
    id: '/review',
    name: '/review',
    description: 'Analyse and review attached documents',
    icon: <FileSearch className="w-4 h-4" strokeWidth={2.5} />
  },
  {
    id: '/refine',
    name: '/refine',
    description: 'Filters out errors to provide the best possible version',
    icon: <Sparkles className="w-4 h-4" strokeWidth={2.5} />
  }
];

export function CommandSelector({ isOpen, searchTerm, onSelect, onClose }: CommandSelectorProps) {
  const filteredCommands = commands.filter(cmd =>
    cmd.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cmd.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AnimatePresence>
      {isOpen && filteredCommands.length > 0 && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={onClose}
          />

          {/* Command Palette */}
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute bottom-full left-0 mb-3 bg-white border border-black/[0.06] rounded-2xl shadow-lg p-2 min-w-[320px] max-w-[400px] z-50"
          >
            <div className="flex flex-col gap-1">
              {filteredCommands.map((command) => (
                <motion.button
                  key={command.id}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    onSelect(command);
                    onClose();
                  }}
                  className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-[#f5f5f4] transition-all duration-200 group"
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5 text-[#646464] group-hover:text-[#171717] transition-colors">
                      {command.icon}
                    </div>
                    <div className="flex-1">
                      <div className="text-[13px] font-medium text-[#171717] mb-0.5">
                        {command.name}
                      </div>
                      <div className="text-[11px] text-[#646464] leading-relaxed">
                        {command.description}
                      </div>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
