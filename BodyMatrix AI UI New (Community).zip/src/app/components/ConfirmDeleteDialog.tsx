import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';

interface ConfirmDeleteDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: () => void;
  title: string;
  description: string;
}

export function ConfirmDeleteDialog({
  open,
  onOpenChange,
  onConfirm,
  title,
  description,
}: ConfirmDeleteDialogProps) {
  const handleConfirm = () => {
    onConfirm();
    onOpenChange(false);
  };

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="bg-white border border-black/[0.06] rounded-2xl shadow-xl w-[90vw] sm:w-full sm:max-w-md">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-[16px] sm:text-[18px] font-medium text-[#171717]">
            {title}
          </AlertDialogTitle>
          <AlertDialogDescription className="text-[13px] sm:text-[14px] text-[#737373] mt-2">
            {description}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="mt-4 sm:mt-6 flex gap-2 sm:gap-3">
          <AlertDialogCancel className="px-4 sm:px-5 py-2.5 text-[13px] sm:text-[14px] font-normal text-[#737373] bg-[#f5f5f4] hover:bg-[#e5e5e5] rounded-xl transition-all duration-200">
            Cancel
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={handleConfirm}
            className="px-4 sm:px-5 py-2.5 text-[13px] sm:text-[14px] font-normal text-white bg-[#dc2626] hover:bg-[#b91c1c] rounded-xl transition-all duration-200"
          >
            Confirm
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
