import { motion, AnimatePresence } from 'motion/react';

interface CommandPaletteProps {
  isOpen: boolean;
  onSelect: (command: string) => void;
}

interface Command {
  key: string;
  label: string;
  description: string;
}

const commands: Command[] = [
  {
    key: 'analyze',
    label: 'Analyze',
    description: 'Review logs and identify trends and risks',
  },
  {
    key: 'diet',
    label: 'Diet',
    description: 'Calculate macros for your diet goal',
  },
  {
    key: 'report',
    label: 'Report',
    description: 'Generate a journey summary report',
  },
  {
    key: 'web',
    label: 'Web',
    description: 'Deep search for sports science insights',
  },
];

export function CommandPalette({ isOpen, onSelect }: CommandPaletteProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          transition={{ duration: 0.15 }}
          className="absolute bottom-full left-0 right-0 mb-4 bg-[#fafafe] border border-black/[0.08] rounded-2xl p-2 shadow-lg"
          style={{ userSelect: 'none' }}
        >
          <div className="space-y-1">
            {commands.map((command) => (
              <button
                key={command.key}
                onClick={() => onSelect(command.key)}
                className="w-full text-left px-4 py-3 rounded-xl hover:bg-white transition-all duration-200 group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[#171717] text-[13px] font-medium mb-0.5">
                      /{command.label.toLowerCase()}
                    </div>
                    <div className="text-[#646464] text-[11px]">
                      {command.description}
                    </div>
                  </div>
                  <div className="text-[#646464] text-[10px] opacity-0 group-hover:opacity-100 transition-opacity">
                    ↵
                  </div>
                </div>
              </button>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
