import { motion } from 'motion/react';
import { SuggestionChip } from './SuggestionChip';

interface EmptyStateProps {
  onSuggestionClick: (text: string) => void;
}

const suggestions = [
  'What is a healthy BMI for my age?',
  'How many calories should I eat daily?',
  'What does my blood pressure reading mean?',
  'How can I improve my resting heart rate?',
  'What foods reduce inflammation?',
  'Summarize my report',
];

export function EmptyState({ onSuggestionClick }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center flex-1 w-full min-h-0 px-4">
      <div className="flex flex-col items-center justify-center w-full max-w-2xl mx-auto">
        <motion.div
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mb-8 md:mb-12 w-full"
        >
        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.4 }}
          className="text-[28px] sm:text-[32px] md:text-[36px] font-medium text-[#171717] mb-4 md:mb-5 tracking-tight"
        >
          How can I help you today?
        </motion.h2>

        {/* Subtext */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.4 }}
          className="text-[15px] md:text-[16px] text-[#737373] max-w-md mx-auto leading-relaxed"
        >
          Ask me about your health data, BMI, nutrition, fitness goals, or anything health-related.
        </motion.p>
      </motion.div>

        {/* Suggestion Chips */}
        <div className="flex flex-wrap justify-center gap-2.5 w-full">
          {suggestions.map((suggestion, index) => (
            <SuggestionChip
              key={suggestion}
              text={suggestion}
              onClick={onSuggestionClick}
              delay={0.4 + index * 0.05}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
