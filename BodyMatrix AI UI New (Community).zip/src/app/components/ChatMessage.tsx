import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Copy, ThumbsUp, ThumbsDown, ChevronDown, ChevronUp, ArrowRight, File, Image as ImageIcon, RefreshCw, Edit as EditIcon } from 'lucide-react';
import { FormattedText } from './FormattedText';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  thinkingTime?: number;
  responseTime?: number;
  suggestions?: string[];
  attachments?: Array<{
    id: string;
    name: string;
    type: 'file' | 'image';
    preview?: string;
    size: number;
  }>;
}

interface ChatMessageProps {
  message: Message;
  onSuggestionClick?: (text: string) => void;
  onRegenerate?: (messageId: string) => void;
  onEditMessage?: (messageId: string, newContent: string) => void;
  isLatestUserMessage?: boolean;
}

export function ChatMessage({ message, onSuggestionClick, onRegenerate, onEditMessage, isLatestUserMessage = false }: ChatMessageProps) {
  const [thoughtExpanded, setThoughtExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [liked, setLiked] = useState(false);
  const [disliked, setDisliked] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message.content);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy text:', err);
      // Fallback method
      const textArea = document.createElement('textarea');
      textArea.value = message.content;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (fallbackErr) {
        console.error('Fallback copy failed:', fallbackErr);
      }
      document.body.removeChild(textArea);
    }
  };

  const handleLike = () => {
    setLiked(!liked);
    if (disliked) setDisliked(false);
  };

  const handleDislike = () => {
    setDisliked(!disliked);
    if (liked) setLiked(false);
  };

  if (message.role === 'user') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className={`mb-6 ${isEditing ? '' : 'flex justify-end'}`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {isEditing ? (
          /* Editing Mode - Grok-style wide container */
          <div className="w-full bg-[#f5f5f4] rounded-3xl p-5 md:p-6">
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className="w-full text-[13px] md:text-[14px] text-[#171717] leading-relaxed bg-transparent border-none outline-none resize-none mb-4"
              rows={editContent.split('\n').length || 1}
              autoFocus
            />
            <div className="flex items-center justify-end gap-4">
              <button
                onClick={() => {
                  setIsEditing(false);
                  setEditContent(message.content);
                }}
                className="text-[13px] text-[#646464] hover:text-[#171717] transition-colors"
              >
                Cancel
              </button>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  if (editContent.trim() && onEditMessage) {
                    onEditMessage(message.id, editContent);
                    setIsEditing(false);
                  }
                }}
                className="px-5 py-2 bg-[#171717] text-white text-[13px] rounded-full hover:bg-[#2a2a2a] transition-colors font-medium"
              >
                Save
              </motion.button>
            </div>
          </div>
        ) : (
          /* Normal Mode - Right-aligned bubble */
          <div className="max-w-[80%] relative">
            <div className="bg-[#f5f5f4] rounded-2xl overflow-hidden">
              {/* Attachments at top if present */}
              {message.attachments && message.attachments.length > 0 && (
                <div className="p-3 border-b border-black/[0.06]">
                  <div className="flex flex-wrap gap-2">
                    {message.attachments.map((file) => (
                      <div
                        key={file.id}
                        className="w-16 h-16 bg-white border border-black/[0.06] rounded-xl overflow-hidden flex items-center justify-center"
                      >
                        {file.type === 'image' && file.preview ? (
                          <img
                            src={file.preview}
                            alt={file.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="flex flex-col items-center gap-1">
                            {file.type === 'image' ? (
                              <ImageIcon className="w-5 h-5 text-[#646464]" strokeWidth={2} />
                            ) : (
                              <File className="w-5 h-5 text-[#646464]" strokeWidth={2} />
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {/* Message content */}
              <div className="px-4 py-3">
                <p className="text-[13px] md:text-[14px] text-[#171717] leading-relaxed whitespace-pre-wrap chat-message-content">
                  {message.content}
                </p>
              </div>
            </div>

            {/* User Message Action Buttons - Below bubble, right-aligned */}
            <AnimatePresence>
              {isHovered && (
                <motion.div
                  initial={{ opacity: 0, y: -2 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -2 }}
                  transition={{ duration: 0.15 }}
                  className="flex items-center justify-end gap-1 mt-1.5"
                >
                  {/* Edit Button - Only show for latest user message */}
                  {isLatestUserMessage && (
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        setIsEditing(true);
                        setEditContent(message.content);
                      }}
                      className="p-1.5 hover:bg-[#f5f5f4] rounded-lg transition-colors"
                      aria-label="Edit message"
                    >
                      <EditIcon className="w-3.5 h-3.5 text-[#646464]" strokeWidth={2.5} />
                    </motion.button>
                  )}

                  {/* Copy Button - Always visible on hover */}
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={handleCopy}
                    className="p-1.5 hover:bg-[#f5f5f4] rounded-lg transition-colors relative"
                    aria-label="Copy message"
                  >
                    <Copy className="w-3.5 h-3.5 text-[#646464]" strokeWidth={2.5} />
                    {copied && (
                      <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-[#171717] text-white text-[10px] px-2 py-1 rounded whitespace-nowrap">
                        Copied!
                      </span>
                    )}
                  </motion.button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="mb-8"
    >
      {/* AI Response Container */}
      <div className="space-y-3">
        {/* Thinking Dropdown */}
        {message.thinkingTime && (
          <div className="mb-2">
            <button
              onClick={() => setThoughtExpanded(!thoughtExpanded)}
              className="flex items-center gap-2 text-[12px] text-[#646464] hover:text-[#171717] transition-colors"
            >
              {thoughtExpanded ? (
                <ChevronUp className="w-3.5 h-3.5" strokeWidth={2.5} />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" strokeWidth={2.5} />
              )}
              <span>Thought for {message.thinkingTime}s</span>
            </button>

            <AnimatePresence>
              {thoughtExpanded && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="mt-2 pl-6 text-[12px] text-[#646464] overflow-hidden"
                >
                  <p className="italic">Deep analysis and reasoning process...</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* AI Response Content - No background box */}
        <div className="py-1">
          <p className="text-[13px] md:text-[14px] text-[#171717] leading-relaxed whitespace-pre-wrap chat-message-content">
            <FormattedText text={message.content} />
          </p>
        </div>

        {/* Action Bar */}
        <div className="flex items-center gap-3 px-1">
          {/* Copy Button */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleCopy}
            className="p-1.5 hover:bg-[#f5f5f4] rounded-lg transition-colors group relative"
            aria-label="Copy response"
          >
            <Copy className="w-3.5 h-3.5 text-[#646464] group-hover:text-[#171717]" strokeWidth={2.5} />
            {copied && (
              <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-[#171717] text-white text-[10px] px-2 py-1 rounded whitespace-nowrap">
                Copied!
              </span>
            )}
          </motion.button>

          {/* Regenerate Button */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => onRegenerate?.(message.id)}
            className="p-1.5 hover:bg-[#f5f5f4] rounded-lg transition-colors group"
            aria-label="Regenerate response"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#646464] group-hover:text-[#171717]" strokeWidth={2.5} />
          </motion.button>

          {/* Like Button */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleLike}
            className="p-1.5 hover:bg-[#f5f5f4] rounded-lg transition-colors group"
            aria-label="Like response"
          >
            <ThumbsUp
              className={`w-3.5 h-3.5 ${liked ? 'text-[#171717] fill-[#171717]' : 'text-[#646464] group-hover:text-[#171717]'}`}
              strokeWidth={2.5}
            />
          </motion.button>

          {/* Dislike Button */}
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleDislike}
            className="p-1.5 hover:bg-[#f5f5f4] rounded-lg transition-colors group"
            aria-label="Dislike response"
          >
            <ThumbsDown
              className={`w-3.5 h-3.5 ${disliked ? 'text-[#171717] fill-[#171717]' : 'text-[#646464] group-hover:text-[#171717]'}`}
              strokeWidth={2.5}
            />
          </motion.button>

          {/* Response Time */}
          {message.responseTime && (
            <span className="text-[11px] text-[#646464] ml-auto">
              {message.responseTime}s
            </span>
          )}
        </div>

        {/* Suggested Questions - Vertical List */}
        {message.suggestions && message.suggestions.length > 0 && (
          <div className="space-y-2 pt-3">
            <p className="text-[11px] text-[#646464] px-1">Suggested questions</p>
            <div className="flex flex-col gap-1.5">
              {message.suggestions.map((suggestion, index) => (
                <motion.button
                  key={index}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => onSuggestionClick?.(suggestion)}
                  className="flex items-center gap-2 text-left px-1 py-1 hover:bg-[#f5f5f4] rounded-lg transition-colors group"
                >
                  <ArrowRight className="w-3.5 h-3.5 text-[#646464] group-hover:text-[#171717] flex-shrink-0 transition-colors" strokeWidth={2.5} />
                  <span className="text-[12px] text-[#646464] group-hover:text-[#171717] transition-colors">
                    {suggestion}
                  </span>
                </motion.button>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
}
