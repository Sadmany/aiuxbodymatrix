import { useState, useEffect, useRef, UIEvent } from 'react';
import { Plus, Menu, X, Search, ChevronDown, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { ChatHistoryItem } from './ChatHistoryItem';
import { ConfirmDeleteDialog } from './ConfirmDeleteDialog';
import { RenameDialog } from './RenameDialog';
import { SearchPopup } from './SearchPopup';
import logoImg from '../../imports/Bodymatrix_AI_logo_png.png';

interface SidebarProps {
  activeChat: string | null;
  onNewChat: () => void;
  onSelectChat: (id: string) => void;
  chatHistory: Array<{
    id: string;
    title: string;
    lastMessageDate: Date;
    isPinned?: boolean;
    messages: any[];
  }>;
  onChatHistoryChange: (history: any[]) => void;
  isOpen: boolean;
  isMiniBar: boolean;
  onToggle: () => void;
  onExpand: () => void;
  isMobile?: boolean;
}

interface ChatItem {
  id: string;
  title: string;
  lastMessageDate: Date;
  isPinned?: boolean;
}

export function Sidebar({
  activeChat,
  onNewChat,
  onSelectChat,
  chatHistory: externalChatHistory,
  onChatHistoryChange,
  isOpen,
  isMiniBar,
  onToggle,
  onExpand,
  isMobile = false
}: SidebarProps) {
  // Use external chat history from App component
  const chatHistory = externalChatHistory as ChatItem[];
  const setChatHistory = onChatHistoryChange;
  const [deleteAllDialogOpen, setDeleteAllDialogOpen] = useState(false);
  const [renameDialogOpen, setRenameDialogOpen] = useState(false);
  const [chatToRename, setChatToRename] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [pinnedExpanded, setPinnedExpanded] = useState(true);
  const [historyExpanded, setHistoryExpanded] = useState(true);
  const [recentExpanded, setRecentExpanded] = useState(true);
  const [earlierExpanded, setEarlierExpanded] = useState(true);
  const [searchPopupOpen, setSearchPopupOpen] = useState(false);
  const [showTopShadow, setShowTopShadow] = useState(false);
  const [showBottomShadow, setShowBottomShadow] = useState(false);
  const historyContainerRef = useRef<HTMLDivElement>(null);

  // Listen for Alt+K shortcut from App component
  useEffect(() => {
    const handleOpenSearch = () => {
      setSearchPopupOpen(true);
    };

    document.addEventListener('openSearchPopup', handleOpenSearch);
    return () => document.removeEventListener('openSearchPopup', handleOpenSearch);
  }, []);

  const handleDeleteChat = (id: string) => {
    // Instant delete - no secondary confirmation popup
    // If deleting current chat, trigger new chat
    if (id === activeChat) {
      onNewChat();
    }
    setChatHistory(chatHistory.filter(chat => chat.id !== id));
  };

  const handleRenameChat = (id: string) => {
    setChatToRename(id);
    setRenameDialogOpen(true);
  };

  const confirmRenameChat = (newTitle: string) => {
    if (chatToRename && newTitle.trim()) {
      setChatHistory(chatHistory.map(chat =>
        chat.id === chatToRename ? { ...chat, title: newTitle } : chat
      ));
      setChatToRename(null);
    }
  };

  const handlePinChat = (id: string) => {
    setChatHistory(chatHistory.map(chat =>
      chat.id === id ? { ...chat, isPinned: !chat.isPinned } : chat
    ));
  };

  const handleDeleteAll = () => {
    setDeleteAllDialogOpen(true);
  };

  const confirmDeleteAll = () => {
    setChatHistory([]);
    onNewChat();
  };

  // Filter chats based on search query
  const filteredChats = chatHistory.filter(chat =>
    chat.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group chats: Pinned, Recent (last 7 days) and Earlier
  const now = new Date();
  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  const pinnedChats = filteredChats.filter(chat => chat.isPinned);
  const recentChats = filteredChats.filter(chat => !chat.isPinned && chat.lastMessageDate >= sevenDaysAgo);
  const earlierChats = filteredChats.filter(chat => !chat.isPinned && chat.lastMessageDate < sevenDaysAgo);

  // Handle scroll shadows for sidebar
  const handleHistoryScroll = (e: UIEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    setShowTopShadow(scrollTop > 10);
    setShowBottomShadow(scrollTop + clientHeight < scrollHeight - 10);
  };

  // Update shadows when chat list changes
  useEffect(() => {
    const container = historyContainerRef.current;
    if (container) {
      const scrollHeight = container.scrollHeight;
      const clientHeight = container.clientHeight;
      setShowBottomShadow(scrollHeight > clientHeight);
    }
  }, [chatHistory, historyExpanded, pinnedExpanded, recentExpanded, earlierExpanded]);

  return (
    <>
      {/* Mini-Bar Mode (PC/Tablet only) */}
      <AnimatePresence mode="wait">
        {isMiniBar && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: '56px', opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{
              duration: 0.3,
              ease: [0.4, 0, 0.2, 1]
            }}
            className="bg-white border-r border-black/[0.06] flex flex-col items-center h-screen fixed lg:relative z-30 py-4 gap-3 overflow-hidden"
          >
            {/* Expand Button */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onExpand}
              className="p-2 hover:bg-[#f5f5f4] rounded-xl transition-all duration-200"
              title="Expand sidebar"
            >
              <Menu className="w-5 h-5 text-[#171717]" strokeWidth={2.5} />
            </motion.button>

            {/* Search Icon */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setSearchPopupOpen(true)}
              className="p-2 hover:bg-[#f5f5f4] rounded-xl transition-all duration-200"
              title="Search chats"
            >
              <Search className="w-5 h-5 text-[#171717]" strokeWidth={2.5} />
            </motion.button>

            {/* New Chat Icon */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onNewChat}
              className="p-2 hover:bg-[#f5f5f4] rounded-xl transition-all duration-200"
              title="New chat"
            >
              <Plus className="w-5 h-5 text-[#171717]" strokeWidth={2.5} />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Full Sidebar */}
      <AnimatePresence mode="wait">
        {isOpen && (
          <motion.div
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: '260px', opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{
              duration: 0.3,
              ease: [0.4, 0, 0.2, 1]
            }}
            className="bg-white border-r border-black/[0.06] flex flex-col h-screen fixed lg:relative z-30 overflow-hidden"
          >
      {/* Header */}
      <div className="p-4 border-b border-black/[0.06]">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 flex items-center justify-center">
              <img
                src={logoImg}
                alt="BodyMatrix AI"
                className="w-full h-full object-contain"
              />
            </div>
            <h1 className="text-[16px] font-medium text-[#171717] tracking-tight">
              BodyMatrix
            </h1>
          </div>
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onToggle}
            className="p-1.5 hover:bg-[#f5f5f4] rounded-xl transition-all duration-200"
            aria-label="Close sidebar"
          >
            <X className="w-4 h-4 text-[#171717]" strokeWidth={2.5} />
          </motion.button>
        </div>

        {/* Search Chat */}
        <div className="mb-3 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#171717] pointer-events-none" strokeWidth={2.5} />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search chats..."
            className="w-full bg-[#f5f5f4] hover:bg-[#ebebeb] focus:bg-white border border-black/[0.08] focus:border-black/[0.12] rounded-xl pl-9 pr-3 py-2.5 text-[14px] font-semibold text-[#171717] placeholder:text-[#646464] placeholder:font-normal outline-none transition-all duration-200"
          />
        </div>

        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={onNewChat}
          className="w-full text-[#171717] hover:bg-[#f5f5f4] rounded-xl px-3 py-2.5 flex items-center gap-2 transition-all duration-200"
        >
          <Plus className="w-4 h-4" strokeWidth={2.5} />
          <span className="text-[14px] font-normal">New chat</span>
        </motion.button>
      </div>

      {/* History with Scroll Shadows */}
      <div className="flex-1 relative">
        {/* Top Scroll Shadow */}
        <AnimatePresence>
          {showTopShadow && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="absolute top-0 left-0 right-0 h-8 pointer-events-none z-10"
              style={{
                background: 'linear-gradient(to bottom, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%)'
              }}
            />
          )}
        </AnimatePresence>

        <div
          ref={historyContainerRef}
          onScroll={handleHistoryScroll}
          className="h-full overflow-y-auto p-3"
          style={{ scrollbarGutter: 'stable' }}
        >
        {/* Pinned Chats Section - Only show if there are pinned chats */}
        {pinnedChats.length > 0 && (
          <div className="mb-4">
            <div className="px-2 mb-2 flex items-center justify-between">
              <span className="text-[11px] font-bold text-[#171717]">
                Pinned chats
              </span>
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => setPinnedExpanded(!pinnedExpanded)}
                className="p-0.5 hover:bg-[#f5f5f4] rounded transition-all duration-200"
              >
                {pinnedExpanded ? (
                  <ChevronDown className="w-3.5 h-3.5 text-[#171717]" strokeWidth={2.5} />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-[#171717]" strokeWidth={2.5} />
                )}
              </motion.button>
            </div>
            <AnimatePresence>
              {(pinnedExpanded || pinnedChats.some(chat => chat.id === activeChat)) && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden space-y-1"
                >
                  {pinnedChats
                    .filter(chat => pinnedExpanded || chat.id === activeChat)
                    .map((chat) => (
                      <ChatHistoryItem
                        key={chat.id}
                        title={chat.title}
                        active={activeChat === chat.id}
                        isPinned={chat.isPinned}
                        onClick={() => onSelectChat(chat.id)}
                        onDelete={() => handleDeleteChat(chat.id)}
                        onRename={() => handleRenameChat(chat.id)}
                        onPin={() => handlePinChat(chat.id)}
                      />
                    ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        <div className="mb-4 px-2 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-[#171717]">
              History
            </span>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setHistoryExpanded(!historyExpanded)}
              className="p-0.5 hover:bg-[#f5f5f4] rounded transition-all duration-200"
            >
              {historyExpanded ? (
                <ChevronDown className="w-3.5 h-3.5 text-[#171717]" strokeWidth={2.5} />
              ) : (
                <ChevronRight className="w-3.5 h-3.5 text-[#171717]" strokeWidth={2.5} />
              )}
            </motion.button>
          </div>
          {chatHistory.length > 0 && (
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleDeleteAll}
              className="text-[12px] text-[#646464] hover:text-[#171717] hover:underline transition-all duration-200"
            >
              Delete all
            </motion.button>
          )}
        </div>

        <AnimatePresence>
          {historyExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              {/* Recent Chats */}
              {recentChats.length > 0 && (
                <div className="mb-4">
                  <div className="px-2 mb-2 flex items-center justify-between">
                    <span className="text-[10px] font-medium text-[#646464]">
                      Recent
                    </span>
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setRecentExpanded(!recentExpanded)}
                      className="p-0.5 hover:bg-[#f5f5f4] rounded transition-all duration-200"
                    >
                      {recentExpanded ? (
                        <ChevronDown className="w-3 h-3 text-[#646464]" strokeWidth={2.5} />
                      ) : (
                        <ChevronRight className="w-3 h-3 text-[#646464]" strokeWidth={2.5} />
                      )}
                    </motion.button>
                  </div>
                  <AnimatePresence>
                    {(recentExpanded || recentChats.some(chat => chat.id === activeChat)) && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden space-y-1"
                      >
                        {recentChats
                          .filter(chat => recentExpanded || chat.id === activeChat)
                          .map((chat) => (
                            <ChatHistoryItem
                              key={chat.id}
                              title={chat.title}
                              active={activeChat === chat.id}
                              isPinned={chat.isPinned}
                              onClick={() => onSelectChat(chat.id)}
                              onDelete={() => handleDeleteChat(chat.id)}
                              onRename={() => handleRenameChat(chat.id)}
                              onPin={() => handlePinChat(chat.id)}
                            />
                          ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}

              {/* Earlier Chats */}
              {earlierChats.length > 0 && (
                <div>
                  <div className="px-2 mb-2 flex items-center justify-between">
                    <span className="text-[10px] font-medium text-[#646464]">
                      Earlier
                    </span>
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={() => setEarlierExpanded(!earlierExpanded)}
                      className="p-0.5 hover:bg-[#f5f5f4] rounded transition-all duration-200"
                    >
                      {earlierExpanded ? (
                        <ChevronDown className="w-3 h-3 text-[#646464]" strokeWidth={2.5} />
                      ) : (
                        <ChevronRight className="w-3 h-3 text-[#646464]" strokeWidth={2.5} />
                      )}
                    </motion.button>
                  </div>
                  <AnimatePresence>
                    {(earlierExpanded || earlierChats.some(chat => chat.id === activeChat)) && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden space-y-1"
                      >
                        {earlierChats
                          .filter(chat => earlierExpanded || chat.id === activeChat)
                          .map((chat) => (
                            <ChatHistoryItem
                              key={chat.id}
                              title={chat.title}
                              active={activeChat === chat.id}
                              isPinned={chat.isPinned}
                              onClick={() => onSelectChat(chat.id)}
                              onDelete={() => handleDeleteChat(chat.id)}
                              onRename={() => handleRenameChat(chat.id)}
                              onPin={() => handlePinChat(chat.id)}
                            />
                          ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
        </div>

        {/* Bottom Scroll Shadow */}
        <AnimatePresence>
          {showBottomShadow && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="absolute bottom-0 left-0 right-0 h-8 pointer-events-none z-10"
              style={{
                background: 'linear-gradient(to top, rgba(255, 255, 255, 1) 0%, rgba(255, 255, 255, 0) 100%)'
              }}
            />
          )}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-black/[0.06]">
        <p className="text-[11px] text-[#646464] text-center">
          Private • BodyMatrix AI
        </p>
      </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Only keep confirmation for Delete All */}
      <ConfirmDeleteDialog
        open={deleteAllDialogOpen}
        onOpenChange={setDeleteAllDialogOpen}
        onConfirm={confirmDeleteAll}
        title="Delete All Chats"
        description="Are you sure you want to delete all chats? This action cannot be undone and will remove all chat history."
      />

      <RenameDialog
        open={renameDialogOpen}
        onOpenChange={setRenameDialogOpen}
        onConfirm={confirmRenameChat}
        currentTitle={chatHistory.find(chat => chat.id === chatToRename)?.title || ''}
      />

      <SearchPopup
        isOpen={searchPopupOpen}
        onClose={() => setSearchPopupOpen(false)}
        chatHistory={chatHistory}
        onSelectChat={onSelectChat}
        activeChat={activeChat}
      />
    </>
  );
}
