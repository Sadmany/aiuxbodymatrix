import { motion, AnimatePresence } from 'motion/react';
import { X, File, Image as ImageIcon } from 'lucide-react';

export interface AttachedFile {
  id: string;
  name: string;
  type: 'file' | 'image';
  preview?: string;
  size: number;
}

interface AttachmentPreviewProps {
  files: AttachedFile[];
  onRemove: (id: string) => void;
}

export function AttachmentPreview({ files, onRemove }: AttachmentPreviewProps) {
  if (files.length === 0) return null;

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="bg-white border border-black/[0.06] border-b-0 rounded-t-[28px] pt-4 px-5 shadow-sm">
        <div className="flex flex-wrap gap-2 pb-3">
          <AnimatePresence mode="popLayout">
            {files.map((file) => (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.2 }}
              className="relative group"
            >
              <div className="w-20 h-20 bg-[#fafafe] border border-black/[0.06] rounded-xl overflow-hidden flex items-center justify-center hover:border-black/[0.12] transition-all duration-200">
                {file.type === 'image' && file.preview ? (
                  <img
                    src={file.preview}
                    alt={file.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center gap-1">
                    {file.type === 'image' ? (
                      <ImageIcon className="w-6 h-6 text-[#646464]" strokeWidth={2} />
                    ) : (
                      <File className="w-6 h-6 text-[#646464]" strokeWidth={2} />
                    )}
                    <span className="text-[9px] text-[#646464] text-center px-1 truncate w-full">
                      {file.name.length > 10 ? file.name.substring(0, 10) + '...' : file.name}
                    </span>
                  </div>
                )}
              </div>
              
              {/* Remove button */}
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => onRemove(file.id)}
                className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-[#f5f5f4] transition-all duration-200 opacity-0 group-hover:opacity-100 border border-black/[0.06]"
                aria-label="Remove attachment"
              >
                <X className="w-3 h-3 text-[#646464]" strokeWidth={2.5} />
              </motion.button>

              {/* File info tooltip */}
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#171717] text-white text-[10px] rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-50">
                {file.name} ({formatFileSize(file.size)})
              </div>
            </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}
