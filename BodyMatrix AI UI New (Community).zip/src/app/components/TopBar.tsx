import { Globe, Lock } from 'lucide-react';

interface TopBarProps {
  internetSearch: boolean;
  onInternetSearchToggle: () => void;
  privateMode: boolean;
  onPrivateModeToggle: () => void;
}

export function TopBar({
  internetSearch,
  onInternetSearchToggle,
  privateMode,
  onPrivateModeToggle
}: TopBarProps) {
  return (
    <div className="absolute top-4 md:top-6 right-4 md:right-6 flex items-center gap-2 md:gap-3 z-10">

      {/* Internet Search Toggle */}
      <div className="flex items-center gap-2 bg-white/95 backdrop-blur-sm px-2.5 md:px-3 py-1.5 md:py-2 rounded-full border border-black/[0.06] shadow-sm flex-shrink-0">
        <Globe className={`w-3.5 h-3.5 md:w-4 md:h-4 flex-shrink-0 transition-all duration-300 self-center ${internetSearch ? 'text-[#171717]' : 'text-[#646464]'}`} strokeWidth={2.5} />
        <span className={`hidden md:inline text-[11px] md:text-[12px] font-medium leading-none transition-all duration-300 self-center ${internetSearch ? 'text-[#171717]' : 'text-[#646464]'}`}>Search</span>
        <button
          onClick={onInternetSearchToggle}
          className={`
            relative w-8 h-[18px] md:w-10 md:h-6 rounded-full transition-all duration-300 flex-shrink-0 self-center
            ${internetSearch ? 'bg-[#171717]' : 'bg-[#e5e5e5]'}
          `}
          aria-label="Toggle internet search"
        >
          <div
            className={`
              absolute top-0.5 w-3.5 h-3.5 md:w-5 md:h-5 bg-white rounded-full shadow-sm
              transition-all duration-300
              ${internetSearch ? 'left-[14px] md:left-[18px]' : 'left-0.5'}
            `}
          />
        </button>
      </div>

      {/* Private Chat Toggle */}
      <div className="flex items-center gap-2 bg-white/95 backdrop-blur-sm px-2.5 md:px-3 py-1.5 md:py-2 rounded-full border border-black/[0.06] shadow-sm flex-shrink-0">
        <Lock className={`w-3.5 h-3.5 md:w-4 md:h-4 flex-shrink-0 transition-all duration-300 self-center ${privateMode ? 'text-[#171717]' : 'text-[#646464]'}`} strokeWidth={2.5} />
        <span className={`hidden md:inline text-[11px] md:text-[12px] font-medium leading-none transition-all duration-300 self-center ${privateMode ? 'text-[#171717]' : 'text-[#646464]'}`}>Private</span>
        <button
          onClick={onPrivateModeToggle}
          className={`
            relative w-8 h-[18px] md:w-10 md:h-6 rounded-full transition-all duration-300 flex-shrink-0 self-center
            ${privateMode ? 'bg-[#171717]' : 'bg-[#e5e5e5]'}
          `}
          aria-label="Toggle private chat"
        >
          <div
            className={`
              absolute top-0.5 w-3.5 h-3.5 md:w-5 md:h-5 bg-white rounded-full shadow-sm
              transition-all duration-300
              ${privateMode ? 'left-[14px] md:left-[18px]' : 'left-0.5'}
            `}
          />
        </button>
      </div>
    </div>
  );
}
