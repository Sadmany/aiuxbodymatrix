import { useState, useEffect, useRef, UIEvent } from 'react';
import { Menu } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Sidebar } from './components/Sidebar';
import { EmptyState } from './components/EmptyState';
import { InputArea, InputAreaRef } from './components/InputArea';
import { TopBar } from './components/TopBar';
import { ChatMessage, Message } from './components/ChatMessage';
import { sendChatMessage, generateChatTitle, type ChatMessage as OllamaChatMessage } from './services/ollamaService';

// Chat history interface for Sidebar
export interface ChatHistoryItem {
  id: string;
  title: string;
  lastMessageDate: Date;
  isPinned?: boolean;
  messages: Message[];
}

export default function App() {
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatHistoryItem[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [sidebarMiniBar, setSidebarMiniBar] = useState(false);
  const [chatKey, setChatKey] = useState(0);
  const [internetSearch, setInternetSearch] = useState(true);
  const [privateMode, setPrivateMode] = useState(false);
  const [responseStyle, setResponseStyle] = useState<'fast' | 'thinking' | 'pro'>('fast');
  const [isMobile, setIsMobile] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState<any[]>([]);
  const [showTopShadow, setShowTopShadow] = useState(false);
  const [showBottomShadow, setShowBottomShadow] = useState(false);
  const [isAIResponding, setIsAIResponding] = useState(false);
  const inputRef = useRef<InputAreaRef>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);

      if (mobile) {
        // Mobile: No mini-bar, just close
        setSidebarMiniBar(false);
        setSidebarOpen(false);
      } else {
        // PC/Tablet: Can use mini-bar
        setSidebarOpen(true);
        setSidebarMiniBar(false);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Keyboard shortcuts engine
  useEffect(() => {
    const handleKeyboardShortcut = (e: KeyboardEvent) => {
      // Only trigger if Alt key is pressed
      if (!e.altKey) return;

      switch (e.key.toLowerCase()) {
        case 'n':
          // Alt + N: New Chat
          e.preventDefault();
          handleNewChat();
          break;
        case 'b':
          // Alt + B: Bidirectional Toggle Sidebar
          e.preventDefault();
          if (isMobile) {
            // Mobile: Simple open/close toggle
            setSidebarOpen(prev => !prev);
          } else {
            // PC/Tablet: Bidirectional toggle between full and minibar
            if (sidebarOpen && !sidebarMiniBar) {
              // Currently open -> Close to minibar
              setSidebarOpen(false);
              setSidebarMiniBar(true);
            } else if (!sidebarOpen && sidebarMiniBar) {
              // Currently minibar -> Open to full
              setSidebarMiniBar(false);
              setSidebarOpen(true);
            } else {
              // Fallback: Open to full
              setSidebarMiniBar(false);
              setSidebarOpen(true);
            }
          }
          break;
        case 'k':
          // Alt + K: Open Search/History Popup
          e.preventDefault();
          // Trigger search popup in sidebar
          document.dispatchEvent(new CustomEvent('openSearchPopup'));
          break;
        case 's':
          // Alt + S: Toggle Internet Search
          e.preventDefault();
          setInternetSearch(prev => !prev);
          break;
        case 'p':
          // Alt + P: Toggle Private Mode
          e.preventDefault();
          setPrivateMode(prev => !prev);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyboardShortcut);
    return () => window.removeEventListener('keydown', handleKeyboardShortcut);
  }, [isMobile, sidebarOpen, sidebarMiniBar]);

  // Auto-close sidebar when focusing on chat in mobile
  useEffect(() => {
    const handleFocusOnChat = () => {
      if (isMobile && sidebarOpen) {
        setSidebarOpen(false);
      }
    };

    // Listen for focus events on input
    const inputElement = document.querySelector('textarea');
    inputElement?.addEventListener('focus', handleFocusOnChat);

    return () => {
      inputElement?.removeEventListener('focus', handleFocusOnChat);
    };
  }, [isMobile, sidebarOpen]);

  // Handle scroll shadows
  const handleScroll = (e: UIEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const scrollTop = container.scrollTop;
    const scrollHeight = container.scrollHeight;
    const clientHeight = container.clientHeight;

    // Show top shadow if scrolled down
    setShowTopShadow(scrollTop > 20);

    // Show bottom shadow if not at bottom
    setShowBottomShadow(scrollTop + clientHeight < scrollHeight - 20);
  };

  // Update shadows when messages change and auto-scroll to bottom
  useEffect(() => {
    const container = chatContainerRef.current;
    if (container && messages.length > 0) {
      const scrollHeight = container.scrollHeight;
      const clientHeight = container.clientHeight;
      setShowBottomShadow(scrollHeight > clientHeight);

      // Auto-scroll to bottom when messages change
      requestAnimationFrame(() => {
        container.scrollTo({
          top: container.scrollHeight,
          behavior: 'smooth'
        });
      });
    }
  }, [messages]);

  const handleNewChat = () => {
    // Save current chat to history before creating new one
    if (activeChat && messages.length > 0) {
      saveChatToHistory();
    }

    setActiveChat(null);
    setInputValue('');
    setMessages([]);
    setChatKey(prev => prev + 1); // Force instant refresh
    // Auto-close sidebar on mobile
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  const handleSelectChat = (id: string) => {
    // Save current chat before switching
    if (activeChat && messages.length > 0) {
      saveChatToHistory();
    }

    // Load selected chat
    const chat = chatHistory.find(c => c.id === id);
    if (chat) {
      setActiveChat(id);
      setMessages(chat.messages);
      setChatKey(prev => prev + 1); // Force instant refresh
    }

    // Auto-close sidebar on mobile
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  // Save current chat to history
  const saveChatToHistory = () => {
    if (!activeChat) return;

    setChatHistory(prevHistory => {
      const existingChatIndex = prevHistory.findIndex(c => c.id === activeChat);

      if (existingChatIndex !== -1) {
        // Update existing chat
        const updatedHistory = [...prevHistory];
        updatedHistory[existingChatIndex] = {
          ...updatedHistory[existingChatIndex],
          messages,
          lastMessageDate: new Date()
        };
        return updatedHistory;
      }

      return prevHistory;
    });
  };

  // Auto-save chat when messages change
  useEffect(() => {
    if (activeChat && messages.length > 0) {
      saveChatToHistory();
    }
  }, [messages]);

  const handleSuggestionClick = (text: string) => {
    setInputValue(text);
    // Focus input and position cursor at end with longer timeout for reliability
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
    // Auto-close sidebar on mobile
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  // Auto-scroll to bottom function
  const scrollToBottom = () => {
    requestAnimationFrame(() => {
      const container = chatContainerRef.current;
      if (container) {
        container.scrollTo({
          top: container.scrollHeight,
          behavior: 'smooth'
        });
      }
    });
  };

  /**
   * OLLAMA INTEGRATION POINT #1: Send Message
   * This function sends user messages to Ollama and receives AI responses
   * Key features:
   * - Manages conversation history
   * - Auto-generates chat titles for new conversations
   * - Handles file attachments
   * - Supports slash commands (/think, /step, etc.)
   */
  const handleSend = async (command?: string | null) => {
    if (inputValue.trim() && !isAIResponding) {
      const currentInput = inputValue;
      const currentAttachments = [...attachedFiles];
      const currentCommand = command || null;

      // Add user message
      const userMessage: Message = {
        id: Date.now().toString(),
        role: 'user',
        content: currentInput,
        attachments: currentAttachments.length > 0 ? currentAttachments : undefined
      };

      // If this is a new chat (no activeChat), create one
      const isNewChat = !activeChat;
      const newChatId = isNewChat ? `chat-${Date.now()}` : activeChat!;

      if (isNewChat) {
        setActiveChat(newChatId);
      }

      setMessages(prev => [...prev, userMessage]);
      setAttachedFiles([]);
      setInputValue('');

      // Scroll to user message
      setTimeout(() => scrollToBottom(), 50);

      // Set AI responding state
      setIsAIResponding(true);

      try {
        // Prepare conversation history for Ollama
        const conversationHistory: OllamaChatMessage[] = [
          ...messages.map(m => ({
            role: m.role as 'user' | 'assistant',
            content: m.content
          })),
          {
            role: 'user' as const,
            content: currentInput
          }
        ];

        // Get AI response from Ollama
        const aiResponse = await sendChatMessage(
          conversationHistory,
          responseStyle,
          currentCommand,
          currentAttachments
        );

        // Create AI message
        const aiMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: aiResponse.content,
          thinkingTime: aiResponse.thinkingTime,
          responseTime: aiResponse.responseTime,
          suggestions: aiResponse.suggestions
        };

        setMessages(prev => [...prev, aiMessage]);

        // Generate chat title for new chats
        if (isNewChat) {
          generateChatTitle(currentInput).then(title => {
            const newChat: ChatHistoryItem = {
              id: newChatId,
              title,
              lastMessageDate: new Date(),
              isPinned: false,
              messages: [userMessage, aiMessage]
            };
            setChatHistory(prev => [newChat, ...prev]);
          });
        }

        // Scroll to AI response
        setTimeout(() => scrollToBottom(), 100);

      } catch (error) {
        console.error('Error getting AI response:', error);

        // Show error message
        const errorMessage: Message = {
          id: Date.now().toString(),
          role: 'assistant',
          content: '⚠️ **Connection Error**\n\nCouldn\'t connect to the AI service. Please check your setup and try again.',
          responseTime: 0,
          suggestions: []
        };
        setMessages(prev => [...prev, errorMessage]);
      } finally {
        setIsAIResponding(false);
      }

      // Auto-close sidebar on mobile when sending
      if (isMobile) {
        setSidebarOpen(false);
      }
    }
  };

  /**
   * OLLAMA INTEGRATION POINT #2: Regenerate Response
   * Allows users to regenerate AI responses with potentially different results
   * Uses the same conversation context but may produce varied outputs
   */
  const handleRegenerate = async (messageId: string) => {
    if (isAIResponding) return;

    // Find the message index
    const messageIndex = messages.findIndex(m => m.id === messageId);
    if (messageIndex === -1) return;

    setIsAIResponding(true);

    try {
      // Get conversation history up to the message before this one
      const conversationHistory: OllamaChatMessage[] = messages
        .slice(0, messageIndex)
        .map(m => ({
          role: m.role as 'user' | 'assistant',
          content: m.content
        }));

      // Get AI response from Ollama
      const aiResponse = await sendChatMessage(
        conversationHistory,
        responseStyle
      );

      // Create new AI message
      const newAiMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: aiResponse.content,
        thinkingTime: aiResponse.thinkingTime,
        responseTime: aiResponse.responseTime,
        suggestions: aiResponse.suggestions
      };

      // Replace the old AI message with new one
      setMessages(prev => [
        ...prev.slice(0, messageIndex),
        newAiMessage,
        ...prev.slice(messageIndex + 1)
      ]);

      // Scroll to regenerated message
      setTimeout(() => scrollToBottom(), 100);

    } catch (error) {
      console.error('Error regenerating response:', error);
    } finally {
      setIsAIResponding(false);
    }
  };

  /**
   * OLLAMA INTEGRATION POINT #3: Edit & Regenerate
   * When users edit their messages, this regenerates the AI response
   * Useful for refining prompts and getting better answers
   */
  const handleEditMessage = async (messageId: string, newContent: string) => {
    if (isAIResponding) return;

    // Find the message and update it
    const messageIndex = messages.findIndex(m => m.id === messageId);
    if (messageIndex === -1) return;

    const updatedMessage = { ...messages[messageIndex], content: newContent };
    const updatedMessages = [...messages.slice(0, messageIndex), updatedMessage];

    // Remove any AI responses after this message
    setMessages(updatedMessages);

    // Scroll to edited message
    setTimeout(() => scrollToBottom(), 50);

    setIsAIResponding(true);

    try {
      // Prepare conversation history
      const conversationHistory: OllamaChatMessage[] = updatedMessages.map(m => ({
        role: m.role as 'user' | 'assistant',
        content: m.content
      }));

      // Get AI response from Ollama
      const aiResponse = await sendChatMessage(
        conversationHistory,
        responseStyle
      );

      // Create new AI message
      const aiMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: aiResponse.content,
        thinkingTime: aiResponse.thinkingTime,
        responseTime: aiResponse.responseTime,
        suggestions: aiResponse.suggestions
      };

      setMessages(prev => [...prev, aiMessage]);

      // Scroll to new AI response
      setTimeout(() => scrollToBottom(), 100);

    } catch (error) {
      console.error('Error generating new response:', error);
    } finally {
      setIsAIResponding(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-[#fafafe]">
      {/* Sidebar */}
      <Sidebar
        activeChat={activeChat}
        onNewChat={handleNewChat}
        onSelectChat={handleSelectChat}
        chatHistory={chatHistory}
        onChatHistoryChange={setChatHistory}
        isOpen={sidebarOpen}
        isMiniBar={sidebarMiniBar}
        isMobile={isMobile}
        onToggle={() => {
          if (isMobile) {
            setSidebarOpen(false);
          } else {
            setSidebarOpen(false);
            setSidebarMiniBar(true);
          }
        }}
        onExpand={() => {
          setSidebarMiniBar(false);
          setSidebarOpen(true);
        }}
      />

      {/* Main Content Area */}
      <div className="flex-1 relative flex flex-col items-center overflow-hidden h-screen">
        {/* Circular Toggle Button (visible when sidebar is fully closed on mobile) */}
        <AnimatePresence>
          {!sidebarOpen && !sidebarMiniBar && isMobile && (
            <motion.button
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              whileTap={{ scale: 0.9 }}
              transition={{ type: 'spring', damping: 20, stiffness: 300 }}
              onClick={() => setSidebarOpen(true)}
              className="fixed top-4 md:top-6 left-4 md:left-6 z-50 w-11 h-11 md:w-12 md:h-12 bg-white rounded-full border border-black/[0.06] hover:bg-[#fafafe] transition-all duration-300 shadow-sm hover:shadow-md flex items-center justify-center"
              aria-label="Open sidebar"
            >
              <Menu className="w-5 h-5 text-[#171717]" strokeWidth={2.5} />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Top Bar */}
        <TopBar
          internetSearch={internetSearch}
          onInternetSearchToggle={() => setInternetSearch(!internetSearch)}
          privateMode={privateMode}
          onPrivateModeToggle={() => setPrivateMode(!privateMode)}
        />

        {/* Centered Chat Container with Edge Shadows */}
        <div className="w-full max-w-3xl flex-1 flex flex-col relative">
          {/* Top Scroll Shadow */}
          <AnimatePresence>
            {showTopShadow && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="absolute top-0 left-0 right-0 h-12 pointer-events-none z-10"
                style={{
                  background: 'linear-gradient(to bottom, rgba(250, 250, 254, 1) 0%, rgba(250, 250, 254, 0) 100%)'
                }}
              />
            )}
          </AnimatePresence>

          {/* Chat Container - Always scrollable with visible scrollbar */}
          <div
            ref={chatContainerRef}
            key={chatKey}
            onScroll={handleScroll}
            className="flex-1 flex flex-col px-4 md:px-6 lg:px-8 overflow-y-auto overflow-x-hidden"
            style={{
              scrollbarGutter: 'stable',
              scrollbarWidth: 'auto',
              WebkitOverflowScrolling: 'touch'
            }}
          >
            {messages.length === 0 ? (
              /* Empty State */
              <EmptyState onSuggestionClick={handleSuggestionClick} />
            ) : (
              /* Chat Messages with Top Margin and 120px Bottom Gap */
              <div className="pt-16 md:pt-20 pb-[120px]">
                {messages.map((message, index) => {
                  // Find the last user message index
                  const lastUserMessageIndex = messages.map((m, i) => m.role === 'user' ? i : -1).filter(i => i !== -1).pop();
                  const isLatestUserMessage = message.role === 'user' && index === lastUserMessageIndex;

                  return (
                    <ChatMessage
                      key={message.id}
                      message={message}
                      onSuggestionClick={handleSuggestionClick}
                      onRegenerate={handleRegenerate}
                      onEditMessage={handleEditMessage}
                      isLatestUserMessage={isLatestUserMessage}
                    />
                  );
                })}
              </div>
            )}
          </div>

          {/* Bottom Scroll Shadow */}
          <AnimatePresence>
            {showBottomShadow && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="absolute bottom-0 left-0 right-0 h-12 pointer-events-none z-10"
                style={{
                  background: 'linear-gradient(to top, rgba(250, 250, 254, 1) 0%, rgba(250, 250, 254, 0) 100%)'
                }}
              />
            )}
          </AnimatePresence>
        </div>

        {/* Footer and Input Area Container - Fixed at bottom, centered with sidebar offset */}
        <motion.div
          animate={{
            marginLeft: isMobile ? 0 : (sidebarOpen && !sidebarMiniBar ? 260 : sidebarMiniBar ? 56 : 0)
          }}
          transition={{
            duration: 0.3,
            ease: [0.4, 0, 0.2, 1]
          }}
          className="fixed bottom-0 left-0 right-0 z-20 flex justify-center pointer-events-none"
        >
          <div
            className="w-full max-w-3xl px-4 md:px-6 lg:px-8 pointer-events-auto"
            style={{
              background: 'linear-gradient(to top, #fafafe 70%, rgba(250, 250, 254, 0.95) 85%, transparent 100%)',
              paddingTop: '1rem',
              paddingBottom: '1.25rem'
            }}
          >
            <InputArea
              ref={inputRef}
              value={inputValue}
              onChange={setInputValue}
              onSend={handleSend}
              responseStyle={responseStyle}
              onResponseStyleChange={setResponseStyle}
              attachedFiles={attachedFiles}
              onAttachedFilesChange={setAttachedFiles}
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}