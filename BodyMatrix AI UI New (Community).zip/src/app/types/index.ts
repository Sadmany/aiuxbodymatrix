/**
 * Type Definitions for AI Chat Application
 *
 * This file contains all shared type definitions used throughout the application.
 * Centralizing types improves maintainability and type safety.
 */

/**
 * Chat Message
 * Represents a single message in a conversation
 */
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  thinkingTime?: number; // Time spent in "thinking mode" (seconds)
  responseTime?: number; // Total response time (seconds)
  suggestions?: string[]; // Follow-up question suggestions
  attachments?: AttachedFile[];
}

/**
 * Attached File
 * Represents a file or image attached to a message
 */
export interface AttachedFile {
  id: string;
  name: string;
  type: 'file' | 'image';
  size: number;
  preview?: string; // Data URL for image preview
}

/**
 * Chat History Item
 * Represents a complete conversation in the chat history
 */
export interface ChatHistoryItem {
  id: string;
  title: string;
  lastMessageDate: Date;
  isPinned?: boolean;
  messages: Message[];
}

/**
 * Response Style
 * Determines how the AI generates responses
 */
export type ResponseStyle = 'fast' | 'thinking' | 'pro';

/**
 * Slash Command
 * Special commands that modify AI behavior
 */
export interface Command {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
}

/**
 * AI Response
 * Structure returned by the Ollama service
 */
export interface AIResponse {
  content: string;
  thinkingTime?: number;
  responseTime: number;
  suggestions: string[];
}

/**
 * Ollama Configuration
 * Settings for the Ollama API connection
 */
export interface OllamaConfig {
  baseURL: string;
  model: string;
  temperature?: number;
  top_p?: number;
  top_k?: number;
}

/**
 * Application State
 * Main application state structure (for future state management)
 */
export interface AppState {
  activeChat: string | null;
  chatHistory: ChatHistoryItem[];
  messages: Message[];
  isAIResponding: boolean;
  sidebarOpen: boolean;
  sidebarMiniBar: boolean;
  internetSearch: boolean;
  privateMode: boolean;
  responseStyle: ResponseStyle;
}
