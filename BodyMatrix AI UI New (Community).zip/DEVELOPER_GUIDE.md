# Developer Guide - AI Chat Application

## Architecture Overview

This is a modern React + TypeScript chat application with Ollama AI integration. The architecture is designed to be clean, maintainable, and easy to extend.

```
src/
├── app/
│   ├── App.tsx                 # Main application component
│   ├── components/             # React components
│   │   ├── ChatMessage.tsx     # Message display with edit/regenerate
│   │   ├── InputArea.tsx       # Message input with attachments
│   │   ├── Sidebar.tsx         # Chat history sidebar
│   │   ├── CommandSelector.tsx # Slash command picker
│   │   └── ...                 # Other UI components
│   ├── services/
│   │   └── ollamaService.ts    # Ollama AI integration
│   └── types/
│       └── index.ts            # TypeScript type definitions
```

## Key Components

### 1. App.tsx - Main Application Logic

The main component orchestrates the entire application:

```typescript
// State Management
- activeChat: Current chat ID
- chatHistory: Array of all conversations
- messages: Current conversation messages
- isAIResponding: Loading state for AI responses

// Key Functions
- handleSend(): Sends messages to Ollama
- handleRegenerate(): Re-generates AI responses
- handleEditMessage(): Edits and re-sends messages
- saveChatToHistory(): Persists chat to history
```

**Integration Points**:
- Search for `OLLAMA INTEGRATION POINT` comments in the code
- These mark where the app communicates with the AI service

### 2. ollamaService.ts - AI Backend

Handles all communication with Ollama:

```typescript
// Main Functions
sendChatMessage()     // Send messages and get AI responses
generateChatTitle()   // Auto-generate chat titles
checkOllamaConnection()  // Health check
getAvailableModels()  // List available AI models
```

**Customization**:
```typescript
// Change the AI model
const DEFAULT_MODEL = 'llama2'; // or 'mistral', 'codellama', etc.

// Adjust response parameters
const getModelOptions = (style) => ({
  temperature: 0.7,  // Creativity (0-1)
  top_p: 0.9,        // Diversity
  top_k: 40          // Vocabulary limit
});
```

### 3. Component Structure

```
┌─────────────────────────────────────┐
│           TopBar                    │
│  [Search] [Private Mode]            │
├──────────┬──────────────────────────┤
│          │                          │
│ Sidebar  │    Chat Container        │
│          │                          │
│ [History]│  ┌────────────────────┐  │
│ [Chats]  │  │ ChatMessage        │  │
│          │  │ ChatMessage        │  │
│          │  │ ...                │  │
│          │  └────────────────────┘  │
│          │                          │
│          │  ┌────────────────────┐  │
│          │  │ InputArea          │  │
│          │  │ [📎] [🎤] [Send]   │  │
│          │  └────────────────────┘  │
└──────────┴──────────────────────────┘
```

## Features Implementation

### 1. Response Styles

Response styles control AI behavior through temperature settings:

```typescript
// Fast: Quick responses, more creative
temperature: 0.7, top_p: 0.9

// Thinking: Analytical, shows reasoning process
temperature: 0.5, top_p: 0.95, displays thinkingTime

// Pro: Precise, factual responses
temperature: 0.3, top_p: 0.98
```

**How to add a new style**:

1. Update the type definition:
```typescript
export type ResponseStyle = 'fast' | 'thinking' | 'pro' | 'creative';
```

2. Add to `getModelOptions()`:
```typescript
case 'creative':
  return {
    temperature: 0.9,
    top_p: 0.95,
    top_k: 50
  };
```

3. Update `ResponseStyleSelector.tsx` component

### 2. Slash Commands

Commands modify AI behavior with system prompts:

```typescript
// Example: /think command
case '/think':
  return 'You are in deep thinking mode. Provide thorough, analytical responses...';
```

**How to add a new command**:

1. Add to `CommandSelector.tsx`:
```typescript
{
  id: '/summarize',
  name: '/summarize',
  description: 'Create a concise summary',
  icon: <FileText className="w-4 h-4" />
}
```

2. Add system prompt in `ollamaService.ts`:
```typescript
case '/summarize':
  return 'Create a brief, comprehensive summary. Focus on key points...';
```

### 3. File Attachments

Currently supports up to 5 files per message:

```typescript
// In InputArea.tsx
const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const files = Array.from(e.target.files || []);
  const remainingSlots = 5 - attachedFiles.length;
  // Process files...
};
```

**Extending attachment support**:

1. **Increase limit**: Change `5` to your desired number
2. **File validation**: Add size/type checks
3. **Ollama integration**: Extract text from files and add to context

Example file processing:
```typescript
// Read file content
const reader = new FileReader();
reader.onload = async (e) => {
  const fileContent = e.target?.result as string;
  // Add to message context
  conversationHistory.push({
    role: 'system',
    content: `File content: ${fileContent}`
  });
};
reader.readAsText(file);
```

### 4. Chat History & Titles

Auto-generated titles using Ollama:

```typescript
// In handleSend()
if (isNewChat) {
  generateChatTitle(currentInput).then(title => {
    const newChat: ChatHistoryItem = {
      id: newChatId,
      title,
      lastMessageDate: new Date(),
      messages: [userMessage, aiMessage]
    };
    setChatHistory(prev => [newChat, ...prev]);
  });
}
```

**Customizing title generation**:

Edit the prompt in `generateChatTitle()`:
```typescript
{
  role: 'system',
  content: 'Generate a title (max 6 words) that captures the main topic...'
}
```

### 5. Message Editing & Regeneration

Users can edit messages and get new AI responses:

```typescript
// Edit flow:
1. User clicks edit → ChatMessage shows textarea
2. User saves → handleEditMessage() called
3. Message updated, conversation trimmed
4. New AI response generated with updated context
```

**Key implementation**:
```typescript
const handleEditMessage = async (messageId, newContent) => {
  // Update message
  const updatedMessages = [...messages.slice(0, messageIndex), updatedMessage];

  // Generate new response
  const conversationHistory = updatedMessages.map(m => ({
    role: m.role,
    content: m.content
  }));

  const aiResponse = await sendChatMessage(conversationHistory);
  // Add new AI message...
};
```

## State Management

Currently using React hooks. For larger apps, consider:

### Option 1: Context API

```typescript
// Create context
const ChatContext = createContext<AppState | null>(null);

// Provider
export function ChatProvider({ children }) {
  const [state, setState] = useState<AppState>(initialState);
  return (
    <ChatContext.Provider value={state}>
      {children}
    </ChatContext.Provider>
  );
}

// Usage
const { activeChat, messages } = useContext(ChatContext);
```

### Option 2: Zustand (Recommended)

```bash
pnpm add zustand
```

```typescript
// store.ts
import { create } from 'zustand';

interface ChatStore extends AppState {
  setActiveChat: (id: string) => void;
  addMessage: (message: Message) => void;
}

export const useChatStore = create<ChatStore>((set) => ({
  activeChat: null,
  messages: [],
  setActiveChat: (id) => set({ activeChat: id }),
  addMessage: (message) => set((state) => ({
    messages: [...state.messages, message]
  })),
}));

// Usage
const { messages, addMessage } = useChatStore();
```

## Performance Optimization

### 1. Message Virtualization

For long conversations, implement virtual scrolling:

```bash
pnpm add react-virtual
```

```typescript
import { useVirtual } from 'react-virtual';

const { virtualItems, totalSize } = useVirtual({
  size: messages.length,
  parentRef: chatContainerRef,
  estimateSize: () => 100,
});

return (
  <div ref={chatContainerRef} style={{ height: totalSize }}>
    {virtualItems.map(virtualItem => (
      <div key={virtualItem.index}>
        <ChatMessage message={messages[virtualItem.index]} />
      </div>
    ))}
  </div>
);
```

### 2. Debounced Auto-Save

```typescript
import { useDebounce } from 'use-debounce';

const [debouncedMessages] = useDebounce(messages, 1000);

useEffect(() => {
  if (activeChat && debouncedMessages.length > 0) {
    saveChatToHistory();
  }
}, [debouncedMessages]);
```

### 3. Memoization

```typescript
import { useMemo, memo } from 'react';

// Memoize expensive computations
const processedMessages = useMemo(() => {
  return messages.map(m => ({
    ...m,
    formatted: formatMessage(m.content)
  }));
}, [messages]);

// Memoize components
export const ChatMessage = memo(({ message }) => {
  // Component logic...
});
```

## Testing

### Unit Tests

```typescript
// ollamaService.test.ts
import { sendChatMessage } from './ollamaService';

describe('ollamaService', () => {
  it('should send message and receive response', async () => {
    const messages = [
      { role: 'user', content: 'Hello' }
    ];

    const response = await sendChatMessage(messages, 'fast');

    expect(response).toHaveProperty('content');
    expect(response).toHaveProperty('responseTime');
  });
});
```

### Integration Tests

```typescript
// App.test.tsx
import { render, screen, fireEvent } from '@testing-library/react';
import App from './App';

test('sends message and shows response', async () => {
  render(<App />);

  const input = screen.getByPlaceholderText(/ask anything/i);
  const sendButton = screen.getByRole('button', { name: /send/i });

  fireEvent.change(input, { target: { value: 'Hello AI' } });
  fireEvent.click(sendButton);

  const aiResponse = await screen.findByText(/This is a/i);
  expect(aiResponse).toBeInTheDocument();
});
```

## Deployment

### Build for Production

```bash
# This environment doesn't support standard builds
# For local development, the dev server is already running
```

### Environment Variables

Create `.env` file:

```bash
VITE_OLLAMA_BASE_URL=http://localhost:11434
VITE_DEFAULT_MODEL=llama2
VITE_ENABLE_ANALYTICS=false
```

Access in code:
```typescript
const OLLAMA_BASE_URL = import.meta.env.VITE_OLLAMA_BASE_URL || 'http://localhost:11434';
```

## Extending the App

### Adding New Features

#### 1. Voice Input

```bash
pnpm add react-speech-recognition
```

```typescript
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';

const { transcript, listening, resetTranscript } = useSpeechRecognition();

const startListening = () => {
  SpeechRecognition.startListening({ continuous: true });
};

useEffect(() => {
  if (transcript) {
    setInputValue(transcript);
  }
}, [transcript]);
```

#### 2. Export Conversations

```typescript
const exportChatAsMarkdown = (chat: ChatHistoryItem) => {
  const markdown = `# ${chat.title}\n\n${
    chat.messages.map(m =>
      `**${m.role === 'user' ? 'You' : 'AI'}**: ${m.content}`
    ).join('\n\n')
  }`;

  const blob = new Blob([markdown], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${chat.title}.md`;
  a.click();
};
```

#### 3. RAG (Retrieval-Augmented Generation)

```typescript
// Vector database integration example
import { Chroma } from 'chromadb';

const client = new Chroma({ path: 'http://localhost:8000' });
const collection = await client.getOrCreateCollection('chat-context');

// Store context
await collection.add({
  documents: [content],
  ids: [id],
  metadatas: [{ source: 'chat' }]
});

// Retrieve relevant context
const results = await collection.query({
  queryTexts: [userMessage],
  nResults: 3
});

// Add to conversation
conversationHistory.push({
  role: 'system',
  content: `Relevant context: ${results.documents.join('\n')}`
});
```

## Troubleshooting

### Common Issues

**Issue**: TypeScript errors after adding features
- Run: `pnpm run type-check`
- Fix type mismatches

**Issue**: State not updating
- Check: Are you mutating state directly?
- Fix: Always use `setState` with new objects/arrays

**Issue**: Ollama connection fails
- Check: Is Ollama running? `ollama list`
- Check: Correct URL in `ollamaService.ts`?
- Check: CORS settings if running on different ports

**Issue**: Slow performance with many messages
- Implement: Virtual scrolling (see Performance section)
- Optimize: Use `React.memo()` on components

## Best Practices

1. **Type Safety**: Always define types for props and state
2. **Error Handling**: Wrap AI calls in try-catch blocks
3. **Loading States**: Show feedback during async operations
4. **Accessibility**: Use semantic HTML and ARIA labels
5. **Code Comments**: Document complex logic and integration points
6. **Modular Code**: Keep components small and focused
7. **Performance**: Memoize expensive operations
8. **Testing**: Write tests for critical user flows

## Resources

- **React**: https://react.dev
- **TypeScript**: https://www.typescriptlang.org
- **Ollama**: https://github.com/ollama/ollama
- **Tailwind CSS**: https://tailwindcss.com
- **Motion**: https://motion.dev

---

**Happy coding! 🚀**

For questions or issues, check the troubleshooting section or consult the Ollama documentation.
