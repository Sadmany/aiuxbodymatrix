# AI Chat Application

A modern, responsive chat application with **Ollama AI integration**, built with React, TypeScript, and Tailwind CSS.

![Version](https://img.shields.io/badge/version-0.0.1-blue)
![React](https://img.shields.io/badge/React-18.3.1-61dafb)
![TypeScript](https://img.shields.io/badge/TypeScript-5.x-3178c6)
![Tailwind](https://img.shields.io/badge/Tailwind-4.1.12-38bdf8)

## ✨ Features

### 🤖 AI Integration
- ✅ **Ollama Support** - Connect to local AI models (Llama 2, Mistral, CodeLlama, etc.)
- ✅ **Response Styles** - Fast, Thinking, and Pro modes for different use cases
- ✅ **Slash Commands** - `/think`, `/step`, `/review`, `/refine` for specialized responses
- ✅ **Auto-generated Titles** - AI creates descriptive chat titles automatically

### 💬 Chat Features
- ✅ **Message Editing** - Edit previous messages and regenerate AI responses
- ✅ **Response Regeneration** - Re-roll AI answers for better results
- ✅ **Suggested Questions** - AI provides relevant follow-up prompts
- ✅ **Thinking Mode** - View AI's reasoning process (when enabled)

### 📎 Attachments
- ✅ **File Support** - Attach up to 5 files per message
- ✅ **Image Preview** - Visual previews for attached images
- ✅ **Context Awareness** - AI acknowledges and processes attached files

### 📚 Chat History
- ✅ **Persistent History** - All conversations saved automatically
- ✅ **Pin Important Chats** - Keep key conversations at the top
- ✅ **Search** - Find conversations quickly
- ✅ **Organized View** - Recent and Earlier sections with collapsible groups

### 🎨 UI/UX
- ✅ **Fully Responsive** - Perfect on mobile, tablet, and desktop
- ✅ **Dark/Light Themes** - Coming soon
- ✅ **Smooth Animations** - Polished Motion animations
- ✅ **Keyboard Shortcuts** - Alt+N (new chat), Alt+B (toggle sidebar), Alt+K (search)
- ✅ **Mini Sidebar** - Space-saving mode for larger screens

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pnpm install
```

### 2. Set Up Ollama (AI Backend)

```bash
# Install Ollama
# Visit: https://ollama.ai/download

# Pull an AI model
ollama pull llama2

# Start Ollama server
ollama serve
```

**For detailed Ollama setup**, see [OLLAMA_SETUP.md](./OLLAMA_SETUP.md)

### 3. Start Development

The Vite dev server is already running! Just start chatting.

## 📖 Documentation

- **[OLLAMA_SETUP.md](./OLLAMA_SETUP.md)** - Complete Ollama integration guide
- **[DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md)** - Architecture, extending features, best practices
- **[ATTRIBUTIONS.md](./ATTRIBUTIONS.md)** - Third-party licenses and credits

## 🏗️ Project Structure

```
src/
├── app/
│   ├── App.tsx                    # Main application component
│   ├── components/                # React components
│   │   ├── ChatMessage.tsx        # Message display with actions
│   │   ├── InputArea.tsx          # Input with attachments & commands
│   │   ├── Sidebar.tsx            # Chat history sidebar
│   │   ├── CommandSelector.tsx    # Slash command picker
│   │   └── ...                    # Other UI components
│   ├── services/
│   │   └── ollamaService.ts       # 🔌 AI backend integration
│   └── types/
│       └── index.ts               # TypeScript definitions
```

## 🎯 Key Integration Points

Look for these comments in the code:

```typescript
// OLLAMA INTEGRATION POINT #1: Send Message
// OLLAMA INTEGRATION POINT #2: Regenerate Response
// OLLAMA INTEGRATION POINT #3: Edit & Regenerate
```

These mark where the app communicates with the AI service.

## ⚙️ Configuration

Edit `src/app/services/ollamaService.ts`:

```typescript
const OLLAMA_BASE_URL = 'http://localhost:11434'; // Ollama server URL
const DEFAULT_MODEL = 'llama2';                   // AI model to use
```

## 🎨 Response Styles

| Style | Temperature | Use Case |
|-------|-------------|----------|
| **Fast** | 0.7 | Quick answers, balanced creativity |
| **Thinking** | 0.5 | Deep analysis, shows reasoning |
| **Pro** | 0.3 | Precise, factual responses |

## 🔧 Slash Commands

| Command | Description |
|---------|-------------|
| `/think` | Deep thinking and analysis mode |
| `/step` | Step-by-step breakdown |
| `/review` | Review attached documents |
| `/refine` | Polished, error-free responses |

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Alt + N` | New chat |
| `Alt + B` | Toggle sidebar |
| `Alt + K` | Search chats |
| `Alt + S` | Toggle internet search |
| `Alt + P` | Toggle private mode |
| `Enter` | Send message |
| `Shift + Enter` | New line |

## 🐛 Troubleshooting

### Connection Error
**Problem**: Can't connect to Ollama

**Solution**:
1. Check if Ollama is running: `ollama list`
2. Start the server: `ollama serve`
3. Verify URL in `ollamaService.ts`

### Model Not Found
**Problem**: Selected model isn't installed

**Solution**:
1. Check installed models: `ollama list`
2. Pull the model: `ollama pull llama2`
3. Update `DEFAULT_MODEL` in config

### Slow Responses
**Problem**: AI takes too long

**Solution**:
1. Use a smaller model (e.g., `mistral`)
2. Switch to "Fast" response style
3. Ensure sufficient system resources

## 🔒 Privacy & Security

- ✅ **100% Local** - Ollama runs on your machine
- ✅ **No Cloud** - No data sent to external servers
- ✅ **Private Conversations** - All chats stay on your device
- ✅ **Open Source** - Full transparency

## 🛠️ Tech Stack

- **React 18.3.1** - UI framework
- **TypeScript** - Type safety
- **Tailwind CSS 4.1** - Styling
- **Motion** - Animations
- **Ollama** - AI backend
- **Vite** - Build tool

## 📦 Dependencies

Key packages:
- `motion` - Smooth animations
- `lucide-react` - Beautiful icons
- `@radix-ui/*` - Accessible UI components
- `react-hook-form` - Form handling
- `sonner` - Toast notifications

## 🤝 Contributing

Want to add features? Check out [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md) for:
- Architecture overview
- How to add new features
- Best practices
- Testing strategies

## 📝 License

This project is private and confidential.

## 🙋 Support

For help with:
- **Setup issues** - See [OLLAMA_SETUP.md](./OLLAMA_SETUP.md)
- **Development** - See [DEVELOPER_GUIDE.md](./DEVELOPER_GUIDE.md)
- **Ollama** - Visit https://github.com/ollama/ollama

## 🎉 What's Next?

Potential enhancements:
- [ ] Streaming responses (show AI typing in real-time)
- [ ] Voice input/output
- [ ] Export conversations (PDF, Markdown)
- [ ] Multi-model support (switch models in UI)
- [ ] RAG integration (vector database for context)
- [ ] Code syntax highlighting
- [ ] Dark mode
- [ ] Mobile app (React Native)

---

**Built with ❤️ using React + Ollama**

Ready to chat? Start the Ollama server and begin your conversation! 🚀
